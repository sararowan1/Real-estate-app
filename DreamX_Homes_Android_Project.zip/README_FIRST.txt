DREAMX HOMES PROPERTY REEL MAKER — v0.16.0 SOURCE UPDATE

Based on the Android source ZIP uploaded in this conversation.

CHANGES IN v0.16.0
- Fixes a severe audio-mixing performance issue: voice RMS/ducking was recalculated for every audio frame by repeatedly scanning an entire 20 ms window. RMS is now calculated once per window, then applied to the samples in that window. This removes the major avoidable CPU bottleneck that could leave export appearing stuck during audio mixing.
- Adds a validation check that AAC encoding actually produced an audio track before continuing to mux the final MP4.
- Keeps the rendered MP4 preview flow, which plays the mixed video containing narration and background music.
- Keeps the existing Gallery save, Downloads copy, and Share flows.
- Updates Android app version to 0.16.0 (versionCode 17) and explicitly targets Java/Kotlin 17.
- Fixes progress dialog line breaks so elapsed/remaining time displays on separate lines.

IMPORTANT
- This package has not been built with Android SDK/Gradle or tested on a physical Android device in this environment.
- The fix targets the expensive audio mixing loop identified in the uploaded source. Device-level codec behavior, Google TTS availability/quota, and actual Gallery/Downloads behavior still require testing.
- Preview still renders a complete MP4 before playback; it is not an instant live preview.
- The Gemini API key is not included.
- Use only music you own or are licensed to use.

VERSION
- versionName: 0.16.0
- versionCode: 17

Version 0.16.4: property photos loop for the complete narration duration; final 10 seconds show the DreamX Homes branded closing card and professional follow message.

Version 0.16.8 fixes:
- Handles app-private file:// photo URIs correctly in Quick Preview and MP4 export.
- Handles app-private file:// soundtrack URIs in preview and audio mixing.
- Reuses successful Charon WAV narration for the same API key + script during Reel export.
- Reduces Gemini TTS connection/read timeout so quota/network failures fall back sooner.

Important: Google AI Studio HTTP 429 means the account/project quota is exhausted. The app cannot bypass Google's quota; it falls back to the phone's Sinhala TTS when available. This source ZIP has not been compiled or tested on a physical device yet.


VERSION 0.16.9 — CLOUD SINHALA MALE VOICE
- Replaces Gemini Charon TTS calls with Microsoft Azure Speech REST TTS.
- Uses official Sri Lankan Sinhala male voice: si-LK-SameeraNeural.
- Natural conversational narration settings; returns WAV audio for preview and MP4 export.
- Voice Settings dialog retains its existing location in the UI and now accepts Azure Speech subscription key + region (example region: southeastasia).
- API key is encrypted using Android Keystore. No key is bundled in this source ZIP.
- Requires an Azure AI Speech resource with Sinhala voice access and available quota/billing. This is cloud TTS, not unlimited/free.
- For production distribution, use a private backend to protect the Azure key rather than embedding a subscription key in a public APK.

NOTES
- Existing main screen layout and colors are unchanged. The Voice Settings dialog now asks for Azure key and region.
- Source ZIP integrity checked only. Android Gradle compilation and physical-device audio tests have not been completed in this environment.
