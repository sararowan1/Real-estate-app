DreamX Homes v0.16.22 - REAL ESTATE TEMPLATE RENDERER FIX

This package updates the four reel templates and fixes the mismatch between the
selection dialog, in-app preview and exported MP4.

Templates:
1. House for Sale
2. House for Rent
3. Land for Sale
4. Commercial Property

Implementation notes:
- The picker now uses the four approved real-estate template names.
- Picker labels use readable dark text on a white dialog background.
- Template thumbnails use the first selected property photo when available.
- A shared PropertyTemplateRenderer draws the same navy / white / gold / leaf-green
  layout in the in-app preview and in the exported MP4.
- The property title, location, details, features, price and phone number are
  rendered in the selected template. Land and commercial templates prioritize
  feature lines; house templates prioritize bedrooms and bathrooms.
- Existing photo transitions, soundtrack handling, optional urgent label,
  thumbnail and final five-second end card code are retained.

Build:
Use the included GitHub Actions workflow. Replace the repository's
DreamX_Homes_Android_Project.zip with the project ZIP from this package.
The source ZIP was structurally checked, but an Android Gradle build and
on-device render test were not available in this environment. Verify the
GitHub Actions build and review an exported reel before publishing.
