DREAMX HOMES REEL MAKER — SOURCE PACKAGE 0.16.0

This package contains the Android project source and a GitHub Actions workflow.

Included application updates carried forward from the 0.15.0 source:
- Gemini TTS request uses the gemini-2.5-flash-tts model endpoint and explicitly requests the Charon voice.
- Gemini audio responses that already contain a WAV header are preserved; raw PCM responses are wrapped in a WAV header.
- Audio export mixes narration and selected background music on one timeline, loops/trims music to the video duration, ducks music while narration is active, encodes AAC, and muxes audio/video samples in timestamp order.
- MP4 muxing checks for empty video/audio tracks and reports meaningful errors.
- Preview implementation and existing project source are retained; this package does not introduce a separate preview render design.

Build configuration:
- Android Gradle Plugin 8.7.3
- Kotlin Android plugin 2.0.21
- Gradle 8.9
- Java and Kotlin JVM target 17
- compileSdk/targetSdk 35, minSdk 26

IMPORTANT:
- The GitHub Actions workflow builds the checked-in project directly. It does not extract an old ZIP or overwrite app/build.gradle.
- This package has not been compiled in this environment and has not been tested on a physical Android device. A successful GitHub Actions build verifies compilation only; it does not prove Gemini API access, narration quality, preview timing, or MP4 playback on every device.
- Add your own Gemini API key inside the app's Voice Settings. Never commit an API key to GitHub.

To use:
1. Extract this ZIP.
2. Replace the contents of your GitHub repository with the extracted project files (including the .github folder).
3. Push to the main branch or run GitHub Actions > Build DreamX Homes APK > Run workflow.
4. Download the DreamX-Homes-debug-apk artifact from a successful run.


v0.15.2 TTS correction: uses the current Gemini 3.8 Flash TTS model on the Gemini Developer API endpoint. The transcript is now sent verbatim and the natural male-presenter delivery guidance is sent as speech metadata, following the current Gemini 3.x TTS request format. Charon remains selected.


Version 0.16.0 changes: after the final MP4 is rendered, preview switches to playback of that exact MP4 so narration and music are heard together with the final video. Export progress begins at 1% and reports preparation before TTS begins. This source package has not been compiled or device-tested in this environment.
