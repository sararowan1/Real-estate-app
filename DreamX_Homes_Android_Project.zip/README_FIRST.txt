DreamX Homes Property Reel Maker - source update v0.6.0

New updates:
- Export dialog now uses a horizontal percentage progress bar and named processing phases.
- Shows elapsed time and a live estimated remaining time. Estimate is approximate and recalculates during export; Android TTS synthesis duration varies by device and voice.
- Selected property photos appear as scrollable thumbnails.
- Each thumbnail has a red X button in its top-right corner to remove that photo before export.
- DreamX Homes watermark moves between upper/lower left/right screen positions every two seconds throughout the video and closing card.
- Existing 1080x1920 MP4 rendering, Sinhala narration integration, music selection, branding, end card, Gallery save and share remain.

Important:
- A moving watermark discourages casual reuse and makes cropping harder, but cannot technically prevent someone from re-editing or reusing a video. For stronger protection, use a visible brand watermark plus copyright/ownership text.
- Estimated remaining time is approximate; the exact duration depends on device performance, photo count, photo resolution, storage speed and installed Sinhala TTS engine.
- Source not yet compiled or tested on a physical Android device. Run GitHub Actions and test before release.


v0.7.0 changes:
- Fixed AAC encoder end-of-stream handling. Previously, if the last PCM input chunk exactly consumed the WAV data, the encoder EOS flag was never queued; the narration conversion could wait indefinitely or fail. The last PCM chunk now carries BUFFER_FLAG_END_OF_STREAM and output is drained until encoder EOS.
- TTS synthesis callback errors are now captured and reported explicitly instead of being treated as successful completion.
- Added a DOWNLOAD action alongside SHARE and CLOSE on the Reel-ready dialog. It copies the already Gallery-saved MP4 to Downloads/DreamX Homes.
- Sinhala narration still depends on the phone having a working Sinhala TTS voice installed. Background music is still skipped when narration is present in this version.
- Not physically tested on device; run GitHub Actions and test narration-enabled export.
