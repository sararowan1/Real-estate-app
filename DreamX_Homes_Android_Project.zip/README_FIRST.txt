DreamX Homes v0.16.21

Template update:
- Replaced the old Luxury / Modern / Cinematic / Social Media choices with four practical DreamX Homes property-reel templates:
  1. House for Sale
  2. House for Rent
  3. Land for Sale
  4. Commercial Property
- Template picker includes small visual sample previews and descriptions for each choice.
- The selected template is reflected in the in-app reel preview and in the exported MP4.
- All four templates use the coordinated DreamX Homes palette: deep navy, white, metallic gold and leaf-green accents.
- Property location, price, bedrooms, bathrooms, features and contact number are populated from the app fields.
- Existing photo transitions, default soundtrack, custom thumbnail, optional custom end card and 5-second final card are retained.
- Updated Android version to 0.16.21 (versionCode 31).

Build:
Use the repository's existing GitHub Actions workflow. No workflow YAML change is required for these app-source updates.

Verification:
The ZIP structure and required Android project files were checked. This environment does not have the Android SDK / Gradle build tool configured, so the APK has NOT been compiled or tested here. Run the GitHub Actions workflow to verify the Android build.
