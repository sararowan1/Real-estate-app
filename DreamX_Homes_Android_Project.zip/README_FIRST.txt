DREAMX HOMES PROPERTY REEL MAKER — v0.16.0 SOURCE UPDATE

Based on the Android source ZIP uploaded in this conversation.

CHANGES IN v0.16.0
- Fixes a severe audio-mixing performance issue: voice RMS/ducking was recalculated for every audio frame by repeatedly scanning an entire 20 ms window. RMS is now calculated once per window, then applied to the samples in that window. This removes the major avoidable CPU bottleneck that could leave export appearing stuck during audio mixing.
- Adds a validation check that AAC encoding actually produced an audio track before continuing to mux the final MP4.
- Keeps the rendered MP4 preview flow, which plays the mixed video containing narration and background music.
- Keeps the existing Gallery save, Downloads copy, and Share flows.
- Updates Android app version to 0.16.0 (versionCode 17) and explicitly targets Java/Kotlin 17.
- Fixes progress dialog line breaks so elapsed/remaining time displays on separate lines.

IMPORTANT
- This package has not been built with Android SDK/Gradle or tested on a physical Android device in this environment.
- The fix targets the expensive audio mixing loop identified in the uploaded source. Device-level codec behavior, Google TTS availability/quota, and actual Gallery/Downloads behavior still require testing.
- Preview still renders a complete MP4 before playback; it is not an instant live preview.
- The Gemini API key is not included.
- Use only music you own or are licensed to use.

VERSION
- versionName: 0.16.0
- versionCode: 17
