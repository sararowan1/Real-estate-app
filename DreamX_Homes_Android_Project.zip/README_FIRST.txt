DreamX Homes v0.16.20

Updates in this source package:
- Automatic video thumbnail uses the first selected property photo.
- Thumbnail overlay includes DreamX Homes branding, property price, location, bedrooms and bathrooms.
- Optional custom thumbnail image upload; custom image is used as the thumbnail background.
- Thumbnail preview button and exported JPEG saved to Pictures/DreamX Homes.
- Existing default DreamX Homes end card remains the default.
- Optional custom end-card image upload and image preview from its selection menu.
- End card duration changed from 10 seconds to exactly 5 seconds at the end of the exported video.
- Default soundtrack, template choices, transitions and urgent label settings retained.

Build:
Upload the contents of this ZIP to the repository as instructed by the existing GitHub Actions workflow.
The Android Gradle build and on-device rendering have NOT been verified in this environment.
