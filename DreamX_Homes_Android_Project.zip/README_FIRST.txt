DREAMX HOMES PROPERTY REEL MAKER — v0.8.0 SOURCE UPDATE

Base: user-confirmed v0.7.0 source. Keep the original v0.7.0 ZIP unchanged as backup.

Included in this v0.8.0 source update:
- Adds Android INTERNET permission.
- Adds Google Gemini TTS request client using Gemini 2.5 Flash Preview TTS, voice Achird, Sinhala locale si-LK.
- Adds in-app AI voice setup to paste the user's own Google AI Studio API key.
- Encrypts the API key at rest with Android Keystore AES/GCM.
- Adds Achird voice preview; falls back to installed Android Sinhala TTS if no key is configured or cloud preview fails.
- Reel export uses Achird when configured, otherwise local Android Sinhala TTS.
- Preserves existing photo selection, preview, reel export, watermark, end card, Gallery save, Download and Share code from v0.7.0.
- App version set to 0.8.0 / versionCode 8.

IMPORTANT LIMITATIONS — DO NOT TREAT THIS AS A FINISHED/TESTED RELEASE:
- This source has not been compiled by GitHub Actions or tested on a physical Android device in this session.
- Google Gemini free-tier availability and quota depend on the user's account, project, region and current Google limits. It is not guaranteed unlimited or permanently free. Google says free-tier content may be used to improve its products; do not submit confidential customer information.
- A key encrypted on the phone is protected at rest, but an API key embedded/used by a client app is not a production-grade secret. For public commercial distribution, move Gemini calls to a private authenticated backend and keep the provider key server-side.
- Simultaneous narration + background music mixing is NOT implemented in this source update. Existing export behaviour keeps narration and skips music when both are selected. True mixing requires a separate PCM decode/mix/encode pipeline and must be tested before claiming it works.
- No API key is included. The user must create their own key at https://aistudio.google.com/api-keys and enter it in the app's "SET UP FREE ACHIRD AI VOICE" screen.

BUILD STEPS:
1. Replace the repository's root DreamX_Homes_Android_Project.zip with this source ZIP (keep the exact filename DreamX_Homes_Android_Project.zip).
2. Commit to the main branch.
3. Run .github/workflows/build-apk.yml in GitHub Actions.
4. Install the APK artifact and test the Achird preview and narration-enabled export. If build fails, share the complete Actions error log before making further changes.


VOICE NATURALNESS UPDATE (v0.8.1 source revision)
- Replaced the long announcer-like voice direction with a short conversational Sri Lankan property-consultant direction.
- Reworked generated Sinhala narration into shorter spoken-style sentences with natural punctuation and pauses.
- This is a prompt/script improvement, not a guarantee that Achird will sound fully human or use a perfect Sri Lankan accent. Listen to PREVIEW SINHALA VOICE before exporting.
- Simultaneous narration + music mixing remains NOT implemented.
- This revision has not yet been compiled or tested on a physical device.

DREAMX HOMES v0.9.0 AUDIO STUDIO UPDATE
- New AudioMixEngine decodes narration and selected music, mixes them into one AAC track, then muxes that track with the rendered video.
- Foreground narration gain is 92% with peak limiting; music defaults to 12% and ducks to 5.5% when speech RMS is detected.
- Music loops when shorter than the video, trims when longer, and fades in/out. The output music duration follows the rendered video duration.
- Use the existing SELECT BACKGROUND MUSIC action to import a locally stored audio file supported by the Android device decoder. Use only music you own or are licensed to use.
- No commercial/trending music tracks are bundled; this avoids copyright/licensing problems. This release provides user-selected music, not an automatically updated viral-music catalogue.
- Version 0.9.0 source. Build and real-device audio verification are still required through GitHub Actions and an Android phone.
