DREAMX HOMES - NATIVE ANDROID STARTER PROJECT
=============================================

IMPORTANT
---------
This ZIP is an Android Studio project, NOT an installable APK.
It is an early starter build. It currently includes:
- Native Android app screen
- Select up to 15 photos
- Property detail fields
- Sinhala narration script template
- On-device Sinhala TTS preview when the phone has a supported Sinhala voice

NOT YET IMPLEMENTED
-------------------
- MP4 video rendering / cinematic transitions
- Embedded soft background music
- Exported animated watermark and end card
- Cloud-quality Sinhala male narration
These need to be completed before this is a full production reel maker.

HOW TO GET A TEST APK WITHOUT WRITING CODE
------------------------------------------
This project includes a GitHub Actions cloud build workflow.

1. On a computer, open https://github.com and create a free account (if needed).
2. Create a NEW repository named DreamX-Homes-Android.
3. Choose "Add file" > "Upload files".
4. Extract this ZIP on your computer and upload the CONTENTS of the folder
   (not the ZIP file itself) into the repository.
5. Commit the uploaded files to the main branch.
6. Open the repository's "Actions" tab.
7. Select "Build DreamX Homes APK" and press "Run workflow".
8. Wait for the workflow to finish successfully.
9. Open the completed workflow run and download the artifact named
   "DreamX-Homes-debug-apk".
10. Extract the downloaded artifact ZIP. It contains app-debug.apk.
11. Send the APK to your Android phone, open it, and allow installation
    from that source if Android asks.

PHONE INSTALLATION
------------------
Download app-debug.apk on your phone. Tap it in Downloads.
If prompted, allow "Install unknown apps" for the browser or file manager
you used, then return and tap Install.

NOTE
----
This is a test/debug APK, not a Play Store release. Do not share it publicly
as a finished commercial app. Keep API keys out of the source project.
