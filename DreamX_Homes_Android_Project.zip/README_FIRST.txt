DREAMX HOMES PROPERTY REEL MAKER — v0.8.0 SOURCE UPDATE

Base: user-confirmed v0.7.0 source. Keep the original v0.7.0 ZIP unchanged as backup.

Included in this v0.8.0 source update:
- Adds Android INTERNET permission.
- Adds Google Gemini TTS request client using Gemini 2.5 Flash Preview TTS, voice Achird, Sinhala locale si-LK.
- Adds in-app AI voice setup to paste the user's own Google AI Studio API key.
- Encrypts the API key at rest with Android Keystore AES/GCM.
- Adds Achird voice preview; falls back to installed Android Sinhala TTS if no key is configured or cloud preview fails.
- Reel export uses Achird when configured, otherwise local Android Sinhala TTS.
- Preserves existing photo selection, preview, reel export, watermark, end card, Gallery save, Download and Share code from v0.7.0.
- App version set to 0.8.0 / versionCode 8.

IMPORTANT LIMITATIONS — DO NOT TREAT THIS AS A FINISHED/TESTED RELEASE:
- This source has not been compiled by GitHub Actions or tested on a physical Android device in this session.
- Google Gemini free-tier availability and quota depend on the user's account, project, region and current Google limits. It is not guaranteed unlimited or permanently free. Google says free-tier content may be used to improve its products; do not submit confidential customer information.
- A key encrypted on the phone is protected at rest, but an API key embedded/used by a client app is not a production-grade secret. For public commercial distribution, move Gemini calls to a private authenticated backend and keep the provider key server-side.
- Simultaneous narration + background music mixing is NOT implemented in this source update. Existing export behaviour keeps narration and skips music when both are selected. True mixing requires a separate PCM decode/mix/encode pipeline and must be tested before claiming it works.
- No API key is included. The user must create their own key at https://aistudio.google.com/api-keys and enter it in the app's "SET UP FREE ACHIRD AI VOICE" screen.

BUILD STEPS:
1. Replace the repository's root DreamX_Homes_Android_Project.zip with this source ZIP (keep the exact filename DreamX_Homes_Android_Project.zip).
2. Commit to the main branch.
3. Run .github/workflows/build-apk.yml in GitHub Actions.
4. Install the APK artifact and test the Achird preview and narration-enabled export. If build fails, share the complete Actions error log before making further changes.
