DREAMX HOMES REEL MAKER — VERSION 0.14.0

Changes in this update:
- The final reel repeats the selected photos as needed until the generated narration has finished, then adds the final five-second DreamX Homes follow card. This prevents the video/audio from ending before the narration completes.
- Gemini TTS now explicitly requests the Charon male voice. If the Gemini request fails, the app shows the error instead of silently switching to the phone's potentially female voice.
- A Gemini API key is required when narration text is present, so the app does not unexpectedly use the Android phone voice.
- Selected background music is shown as a visible selected-track row with an X button to remove it.
- Added a PREVIEW SELECTED MUSIC action. Reel Preview starts the selected music and stops it when the preview closes. The music volume slider also adjusts preview playback.
- Final MP4 audio mixing continues to loop/trim the selected music to the video duration and duck it under narration.

BUILD:
1. Replace the repository contents with this project.
2. Push to main or open GitHub Actions > Build DreamX Homes APK > Run workflow.
3. Download the DreamX-Homes-debug-apk artifact after a successful build.

This is source code, not a compiled APK. It has not been compiled or tested on a physical Android device in this session.


Version 0.15.0 fixes: Gemini TTS model endpoint updated to gemini-2.5-flash-tts; preserves already-WAV responses instead of wrapping a second WAV header; hardens AAC/MP4 muxer start/stop/sample handling and reports empty-track failures.
