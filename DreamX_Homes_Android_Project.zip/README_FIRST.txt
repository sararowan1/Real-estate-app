DREAMX HOMES — v0.16.17 OPTIONAL CUSTOM VIDEO LABEL

BASED ON
- The v0.16.16 source package supplied in this conversation.

ADDED IN v0.16.17
- Added an optional on-video label setting. It is OFF by default.
- Users can enable or disable the blinking-bulb label.
- Users can enter their own label text (for example: URGENT SALE, PRICE REDUCED, or NEW LISTING).
- Users can set the label text colour with a HEX colour value (for example #FF3333, #FFFFFF, or #FFD700).
- The bulb remains red and blinking; the chosen colour applies to the label text.
- The selected enabled state, text, and colour are applied to both the quick Preview and exported MP4 photo sequence.
- Existing default background music and other existing settings are retained.

TESTING STATUS
- ZIP archive integrity is checked.
- Android Gradle build and real-device testing have not been performed in this environment. Run GitHub Actions before installing the APK.

VERSION
- versionName: 0.16.17
- versionCode: 28
