DreamX Homes Property Reel Maker - source update v0.4.0

Implemented in source:
- Up to 15 selected property photos
- Editable Sinhala property script and phone TTS voice preview
- Play/Pause photo preview
- Full HD 1080x1920 H.264 MP4 rendering with cinematic slow zoom, branding, overlays and end card
- Save to Gallery and Android share sheet
- Optional licensed AAC/M4A music when no narration script is entered
- When a Sinhala script is present, the app synthesizes it with the installed Android Sinhala TTS engine, prefers a voice whose name suggests male when available, encodes it to AAC, and muxes it into the MP4.

Important voice limitations:
- Android TTS does not expose reliable voice-gender metadata. The app can prefer an installed voice whose name suggests male, but cannot guarantee a professional male voice on every phone.
- Sinhala voice data must be installed on the phone. If unavailable, MP4 export reports a clear error instead of silently creating a video without narration.
- When narration is included, selected background music is skipped in this version so speech remains clear. When no script is entered, selected AAC/M4A background music is added instead.
- The project has not been compiled in this environment or tested on a physical Android phone. Run GitHub Actions and test an export before release.
