DREAMX HOMES REEL MAKER — VERSION 0.13.0

Preview fixes and improvements:
- Preview now displays the selected property photos immediately as a lightweight slideshow; it does not wait for a full 1080p MP4 render.
- Preview image decoding runs off the UI thread and uses downsampled images to reduce startup delay and memory use.
- The preview follows the export sequence: selected photos in order, approximately 2 seconds per photo, then a 5-second closing sequence that loops photos behind the DreamX Homes follow message.
- The final 1080 x 1920 H.264 MP4 is rendered in the background at the existing high-quality settings.
- Gallery export continues to use the prepared final MP4.

IMPORTANT PREVIEW DIFFERENCE:
The instant preview is a lightweight visual preview, not the final MP4 player. It mirrors photo order and slide/end-card timing, but it does not reproduce final video transitions, text overlays, narration, or music with frame-perfect synchronization. The exported MP4 remains the full-quality final output.

LOGO NOTE:
The official DreamX Homes logo has not yet been supplied. The app uses a temporary text/vector brand mark in the final video.

BUILD:
1. Replace the repository contents with this project.
2. Push to main or run GitHub Actions > Build DreamX Homes APK > Run workflow.
3. Download the DreamX-Homes-debug-apk artifact after a successful build.

This is source code, not a compiled APK. It has not been built or tested on a physical Android device in this session.
