DreamX Homes Property Reel Maker - source update v0.5.0

Fixes in this update:
- Replaced WAV MediaExtractor decoding for TTS output with direct RIFF/WAV PCM parsing and AAC encoding. This addresses a likely cause of the export failing after video rendering reaches 100%.
- Improved export error messages to show the exception type and details instead of the generic "Unknown error".
- Improved preview hierarchy: prominent uppercase property location, larger price, clear bedroom/bathroom line, features, Call/WhatsApp contact and consistent DREAMX HOMES branding.
- Brand label is consistently DreamX Homes.

Existing features retained:
- Up to 15 photos
- Sinhala script generation and editing
- Sinhala TTS narration generation and AAC embedding (depends on installed Sinhala TTS voice data)
- Full HD 1080x1920 H.264 video rendering
- Cinematic slow zoom, property overlays, watermark and end card
- Optional licensed AAC/M4A background music when narration is blank
- Gallery save and Android share sheet

Important limitations:
- The exact previous device failure is not confirmed because the app only showed "Unknown error". The WAV-to-AAC conversion path was a likely failure point and has been corrected.
- A male Sinhala voice cannot be guaranteed; the app prefers an installed voice whose name suggests male when possible.
- When narration is included, selected background music is skipped in this version.
- This source has not been compiled or tested on a physical Android device in this environment. Run GitHub Actions and retry export. If it fails, the new message should show a more specific error.
