package com.dreamxhomes.reelmaker

import android.content.Context
import android.graphics.*
import android.media.MediaCodec
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.MediaExtractor
import android.net.Uri
import android.view.Surface
import java.io.File
import java.nio.ByteBuffer
import kotlin.math.max
import kotlin.math.min

/**
 * Creates a portrait H.264 MP4 using Android's hardware video encoder.
 * The output is silent; licensed music can be added in the social platform editor.
 */
class ReelVideoExporter(private val context: Context) {
    data class Details(
        val location: String,
        val price: String,
        val bedrooms: String,
        val bathrooms: String,
        val features: String,
        val phone: String,
        val narration: String
    )

    fun export(
        photos: List<Uri>, details: Details, photoDurationSeconds: Int,
        template: String = "Luxury",
        transition: String = "Smooth Fade",
        transitionSpeed: String = "Normal",
        onProgress: (Int) -> Unit
    ): File {
        require(photos.isNotEmpty()) { "Select at least one photo." }
        val width = 1080
        val height = 1920
        val fps = 24
        val secondsPerPhoto = 2
        // Keep cycling through the selected photos until the narration/description finishes.
        val photoFrames = photoDurationSeconds.coerceAtLeast(5) * fps
        val framesPerSlide = secondsPerPhoto * fps
        val transitionFrames = when (transitionSpeed) { "Slow" -> 18; "Fast" -> 6; else -> 12 }
        val endCardSeconds = 10
        val totalFrames = photoFrames + endCardSeconds * fps
        val output = File(context.cacheDir, "dreamx_reel_${System.currentTimeMillis()}.mp4")
        val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfoCompat.COLOR_FORMAT_SURFACE)
            setInteger(MediaFormat.KEY_BIT_RATE, 8_000_000)
            setInteger(MediaFormat.KEY_FRAME_RATE, fps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2)
        }
        val encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        var muxer: MediaMuxer? = null
        var inputSurface: Surface? = null
        var muxerStarted = false
        var trackIndex = -1
        var framesWritten = 0
        val bufferInfo = MediaCodec.BufferInfo()

        fun drain(endOfStream: Boolean) {
            while (true) {
                val outputIndex = encoder.dequeueOutputBuffer(bufferInfo, if (endOfStream) 10_000 else 0)
                when {
                    outputIndex == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                        if (!endOfStream) return
                    }
                    outputIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        check(!muxerStarted) { "Encoder output format changed twice." }
                        muxer = MediaMuxer(output.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
                        trackIndex = muxer!!.addTrack(encoder.outputFormat)
                        muxer!!.start()
                        muxerStarted = true
                    }
                    outputIndex >= 0 -> {
                        val encoded = encoder.getOutputBuffer(outputIndex)
                        if (encoded != null && bufferInfo.size > 0 && muxerStarted &&
                            bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG == 0) {
                            encoded.position(bufferInfo.offset)
                            encoded.limit(bufferInfo.offset + bufferInfo.size)
                            muxer!!.writeSampleData(trackIndex, encoded, bufferInfo)
                        }
                        val eos = bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                        encoder.releaseOutputBuffer(outputIndex, false)
                        if (eos) return
                    }
                }
            }
        }

        try {
            encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            inputSurface = encoder.createInputSurface()
            encoder.start()

            val canvasPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
            val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                textAlign = Paint.Align.CENTER
                typeface = Typeface.create("sans-serif", Typeface.BOLD)
            }
            val goldPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(220, 185, 112)
                textAlign = Paint.Align.CENTER
                typeface = Typeface.create("sans-serif", Typeface.BOLD)
            }
            val overlayPaint = Paint().apply { color = Color.argb(155, 7, 19, 15) }
            val blackPaint = Paint().apply { color = Color.rgb(12, 25, 20) }
            val templateGold = when (template) {
                "Modern" -> Color.rgb(226, 232, 228)
                "Cinematic" -> Color.rgb(225, 190, 125)
                "Social Media" -> Color.rgb(255, 255, 255)
                else -> Color.rgb(220, 185, 112)
            }
            val templateHeader = when (template) {
                "Modern" -> Color.rgb(24, 39, 52)
                "Cinematic" -> Color.rgb(9, 12, 18)
                "Social Media" -> Color.rgb(22, 28, 44)
                else -> Color.rgb(12, 25, 20)
            }
            val movingWatermarkPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.argb(125, 238, 205, 132)
                textAlign = Paint.Align.CENTER
                typeface = Typeface.create("sans-serif", Typeface.BOLD)
                textSize = 34f
            }
            var watermarkFrame = 0
            fun drawMovingWatermark(canvas: Canvas) {
                // Cycle around all four screen quadrants so a static crop cannot remove the brand.
                val positions = listOf(
                    width * 0.22f to height * 0.20f,
                    width * 0.78f to height * 0.28f,
                    width * 0.25f to height * 0.76f,
                    width * 0.75f to height * 0.83f
                )
                val pos = positions[(watermarkFrame / (fps * 2)) % positions.size]
                canvas.save()
                canvas.rotate(-18f, pos.first, pos.second)
                canvas.drawText("DreamX Homes", pos.first, pos.second, movingWatermarkPaint)
                canvas.restore()
                watermarkFrame++
            }
            var activePhotoIndex = -1
            var activeBitmap: Bitmap? = null
            for (photoFrame in 0 until photoFrames) {
                val photoIndex = (photoFrame / framesPerSlide) % photos.size
                val frameInSlide = photoFrame % framesPerSlide
                if (photoIndex != activePhotoIndex) {
                    activeBitmap?.recycle()
                    activeBitmap = decodeForVideo(photos[photoIndex], width, height)
                    activePhotoIndex = photoIndex
                }
                val bitmap = activeBitmap ?: error("Could not decode selected photo.")
                val canvas = inputSurface!!.lockCanvas(null)
                try {
                    canvas.drawColor(templateHeader)
                    val progress = frameInSlide.toFloat() / framesPerSlide
                    val motionProgress = when (transition) {
                        "Zoom Out" -> 1.075f - 0.075f * progress
                        "Ken Burns" -> 1.0f + 0.09f * progress
                        else -> 1.0f + 0.075f * progress
                    }
                    when (transition) {
                        "Slide Left" -> {
                            val reveal = (frameInSlide.toFloat() / transitionFrames).coerceIn(0f, 1f)
                            canvas.save()
                            canvas.clipRect(width * (1f - reveal), 0f, width.toFloat(), height.toFloat())
                            drawCover(canvas, bitmap, width, height, motionProgress, canvasPaint)
                            canvas.restore()
                        }
                        "Slide Right" -> {
                            val reveal = (frameInSlide.toFloat() / transitionFrames).coerceIn(0f, 1f)
                            canvas.save()
                            canvas.clipRect(0f, 0f, width * reveal, height.toFloat())
                            drawCover(canvas, bitmap, width, height, motionProgress, canvasPaint)
                            canvas.restore()
                        }
                        else -> drawCover(canvas, bitmap, width, height, motionProgress, canvasPaint)
                    }

                    val edge = min(frameInSlide, framesPerSlide - 1 - frameInSlide)
                    val fadeAlpha = when (transition) {
                        "Smooth Fade" -> if (frameInSlide < transitionFrames) ((transitionFrames - frameInSlide) * 255 / transitionFrames).coerceIn(0, 255) else 0
                        else -> if (frameInSlide < 3) ((3 - frameInSlide) * 28) else 0
                    }
                    if (fadeAlpha > 0 && transition == "Smooth Fade") canvas.drawColor(Color.argb(fadeAlpha, 0, 0, 0))

                    val headerPaint = Paint(blackPaint).apply { color = templateHeader }
                    canvas.drawRect(0f, 0f, width.toFloat(), 104f, headerPaint)
                    goldPaint.color = templateGold
                    goldPaint.textSize = 42f
                    canvas.drawText("DREAMX HOMES", width / 2f, 68f, goldPaint)

                    val infoOverlay = Paint(overlayPaint).apply {
                        color = when (template) {
                            "Modern" -> Color.argb(175, 18, 34, 45)
                            "Cinematic" -> Color.argb(185, 5, 8, 14)
                            "Social Media" -> Color.argb(180, 25, 30, 52)
                            else -> Color.argb(155, 7, 19, 15)
                        }
                    }
                    canvas.drawRect(0f, height - 360f, width.toFloat(), height.toFloat(), infoOverlay)
                    textPaint.textSize = if (template == "Social Media") 40f else 36f
                    canvas.drawText("PROPERTY FOR SALE", width / 2f, height - 290f, goldPaint)
                    textPaint.textSize = 31f
                    drawWrapped(canvas, details.location.ifBlank { "Sri Lanka" }, width / 2f, height - 235f, textPaint, 1)
                    textPaint.textSize = 38f
                    drawWrapped(canvas, details.price, width / 2f, height - 175f, goldPaint, 1)
                    textPaint.textSize = 27f
                    val bedBath = listOf(
                        details.bedrooms.takeIf { it.isNotBlank() }?.let { "$it Bedrooms" },
                        details.bathrooms.takeIf { it.isNotBlank() }?.let { "$it Bathrooms" }
                    ).filterNotNull().joinToString("  •  ")
                    drawWrapped(canvas, bedBath, width / 2f, height - 125f, textPaint, 1)
                    textPaint.textSize = 23f
                    drawWrapped(canvas, details.phone, width / 2f, height - 75f, goldPaint, 1)
                    textPaint.textSize = 20f
                    canvas.drawText("DREAMX HOMES", width / 2f, height - 28f, goldPaint)
                    drawMovingWatermark(canvas)
                } finally {
                    inputSurface!!.unlockCanvasAndPost(canvas)
                }
                Thread.sleep(1000L / fps)
                framesWritten++
                if (framesWritten % 12 == 0) {
                    onProgress((framesWritten * 95 / totalFrames).coerceIn(1, 95))
                }
                drain(false)
            }
            activeBitmap?.recycle()

            // Final 10-second premium branded end card.
            repeat(endCardSeconds * fps) { frame ->
                val canvas = inputSurface!!.lockCanvas(null)
                try {
                    val deepGreen = Color.rgb(10, 25, 20)
                    val panelGreen = Color.rgb(15, 35, 28)
                    val gold = Color.rgb(207, 172, 105)
                    val softWhite = Color.rgb(239, 237, 229)
                    val muted = Color.rgb(177, 185, 175)
                    canvas.drawColor(deepGreen)

                    val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = Color.rgb(112, 88, 54)
                        style = Paint.Style.STROKE
                        strokeWidth = 2.5f
                    }
                    val inset = 58f
                    canvas.drawRoundRect(
                        inset, 58f, width - inset, height - 58f,
                        18f, 18f, borderPaint
                    )

                    val centerX = width / 2f
                    val centerY = height / 2f
                    val smallCaps = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = muted
                        textAlign = Paint.Align.CENTER
                        textSize = 25f
                        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                        letterSpacing = 0.18f
                    }
                    canvas.drawText("SRI LANKA  •  PROPERTY COLLECTION", centerX, centerY - 365f, smallCaps)

                    // Simple, balanced DX monogram inside a fine gold seal.
                    val sealY = centerY - 650f
                    val sealPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = gold
                        style = Paint.Style.STROKE
                        strokeWidth = 3f
                    }
                    canvas.drawCircle(centerX, sealY, 94f, sealPaint)
                    canvas.drawCircle(centerX, sealY, 82f, Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = Color.argb(75, 207, 172, 105)
                        style = Paint.Style.STROKE
                        strokeWidth = 1.5f
                    })
                    val monogram = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = softWhite
                        textAlign = Paint.Align.CENTER
                        textSize = 72f
                        typeface = Typeface.create("serif", Typeface.NORMAL)
                    }
                    canvas.drawText("DX", centerX, sealY + 25f, monogram)

                    val wordmark = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = gold
                        textAlign = Paint.Align.CENTER
                        textSize = 82f
                        typeface = Typeface.create("serif", Typeface.BOLD)
                        letterSpacing = 0.08f
                    }
                    canvas.drawText("DREAMX", centerX, centerY - 485f, wordmark)

                    val homes = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = softWhite
                        textAlign = Paint.Align.CENTER
                        textSize = 38f
                        typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
                        letterSpacing = 0.42f
                    }
                    canvas.drawText("H O M E S", centerX, centerY - 425f, homes)

                    val rulePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = gold
                        strokeWidth = 2f
                    }
                    canvas.drawLine(width * 0.29f, centerY - 330f, width * 0.71f, centerY - 330f, rulePaint)

                    val follow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = gold
                        textAlign = Paint.Align.CENTER
                        textSize = 36f
                        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                        letterSpacing = 0.08f
                    }
                    canvas.drawText("FOLLOW DREAMX HOMES", centerX, centerY + 135f, follow)

                    val message = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = softWhite
                        textAlign = Paint.Align.CENTER
                        textSize = 31f
                        typeface = Typeface.create("sans-serif", Typeface.NORMAL)
                    }
                    canvas.drawText("Follow us for new land, houses and apartments.", centerX, centerY + 205f, message)
                    canvas.drawText("Find your next property with DreamX Homes.", centerX, centerY + 255f, message)

                    val ctaRect = RectF(width * 0.22f, centerY + 330f, width * 0.78f, centerY + 425f)
                    canvas.drawRoundRect(ctaRect, 12f, 12f, Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = gold
                        style = Paint.Style.FILL
                    })
                    val cta = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = deepGreen
                        textAlign = Paint.Align.CENTER
                        textSize = 29f
                        typeface = Typeface.create("sans-serif-bold", Typeface.BOLD)
                        letterSpacing = 0.04f
                    }
                    canvas.drawText("FOLLOW  •  DISCOVER  •  FIND", centerX, centerY + 389f, cta)

                    val footer = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = muted
                        textAlign = Paint.Align.CENTER
                        textSize = 23f
                        typeface = Typeface.create("sans-serif", Typeface.NORMAL)
                        letterSpacing = 0.12f
                    }
                    canvas.drawText("YOUR NEXT HOME STARTS HERE", centerX, centerY + 500f, footer)
                } finally {
                    inputSurface!!.unlockCanvasAndPost(canvas)
                }
                Thread.sleep(1000L / fps)
                framesWritten++
                if (framesWritten % 12 == 0) onProgress((framesWritten * 95 / totalFrames).coerceIn(1, 95))
                drain(false)
            }

            encoder.signalEndOfInputStream()
            drain(true)
            check(muxerStarted && output.exists() && output.length() > 10_000L) {
                "Video encoder did not produce a valid MP4."
            }
            onProgress(100)
            return output
        } finally {
            runCatching { inputSurface?.release() }
            runCatching { encoder.stop() }
            runCatching { encoder.release() }
            runCatching { if (muxerStarted) muxer?.stop() }
            runCatching { muxer?.release() }
        }
    }


    /**
     * Adds a user-selected AAC/M4A soundtrack to the rendered MP4.
     * The source track is trimmed to the video duration. Use a licensed audio file.
     */
    fun addMusic(videoFile: File, musicUri: Uri): File {
        val extractor = MediaExtractor()
        val videoExtractor = MediaExtractor()
        val output = File(context.cacheDir, "dreamx_music_${System.currentTimeMillis()}.mp4")
        var muxer: MediaMuxer? = null
        try {
            extractor.setDataSource(context, musicUri, null)
            videoExtractor.setDataSource(videoFile.absolutePath)
            var audioTrack = -1
            for (i in 0 until extractor.trackCount) {
                val mime = extractor.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: ""
                if (mime.startsWith("audio/")) { audioTrack = i; break }
            }
            require(audioTrack >= 0) { "Choose an AAC/M4A audio file for background music." }
            val sourceAudioFormat = extractor.getTrackFormat(audioTrack)
            val audioMime = sourceAudioFormat.getString(MediaFormat.KEY_MIME) ?: ""
            require(audioMime == "audio/mp4a-latm") {
                "This soundtrack format is not MP4-compatible. Please choose an AAC/M4A file."
            }
            var videoTrack = -1
            for (i in 0 until videoExtractor.trackCount) {
                val mime = videoExtractor.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: ""
                if (mime.startsWith("video/")) { videoTrack = i; break }
            }
            require(videoTrack >= 0) { "Rendered video track is missing." }
            val videoFormat = videoExtractor.getTrackFormat(videoTrack)
            val durationUs = videoFormat.getLong(MediaFormat.KEY_DURATION)
            muxer = MediaMuxer(output.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val activeMuxer = muxer!!
            val outVideo = activeMuxer.addTrack(videoFormat)
            val outAudio = activeMuxer.addTrack(sourceAudioFormat)
            activeMuxer.start()

            fun copyTrack(ex: MediaExtractor, sourceTrack: Int, targetTrack: Int, trimDuration: Long) {
                ex.selectTrack(sourceTrack)
                val buffer = ByteBuffer.allocate(1 shl 20)
                val info = MediaCodec.BufferInfo()
                while (true) {
                    buffer.clear()
                    val size = ex.readSampleData(buffer, 0)
                    if (size < 0) break
                    val pts = ex.sampleTime
                    if (pts < 0 || pts > trimDuration) break
                    info.set(0, size, pts, ex.sampleFlags)
                    muxer!!.writeSampleData(targetTrack, buffer, info)
                    if (!ex.advance()) break
                }
                ex.unselectTrack(sourceTrack)
            }
            copyTrack(videoExtractor, videoTrack, outVideo, durationUs)
            copyTrack(extractor, audioTrack, outAudio, durationUs)
            muxer!!.stop()
            return output
        } catch (e: Exception) {
            output.delete()
            throw e
        } finally {
            runCatching { muxer?.release() }
            runCatching { extractor.release() }
            runCatching { videoExtractor.release() }
        }
    }


    /** Muxes generated narration AAC into the rendered MP4. */
    fun addNarration(videoFile: File, narrationFile: File): File {
        val audioExtractor = MediaExtractor()
        val videoExtractor = MediaExtractor()
        val output = File(context.cacheDir, "dreamx_narrated_${System.currentTimeMillis()}.mp4")
        var muxer: MediaMuxer? = null
        try {
            audioExtractor.setDataSource(narrationFile.absolutePath)
            videoExtractor.setDataSource(videoFile.absolutePath)
            var audioTrack = -1
            for (i in 0 until audioExtractor.trackCount) {
                val mime = audioExtractor.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: ""
                if (mime.startsWith("audio/")) { audioTrack = i; break }
            }
            require(audioTrack >= 0) { "Generated narration audio track is missing." }
            val audioFormat = audioExtractor.getTrackFormat(audioTrack)
            var videoTrack = -1
            for (i in 0 until videoExtractor.trackCount) {
                val mime = videoExtractor.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: ""
                if (mime.startsWith("video/")) { videoTrack = i; break }
            }
            require(videoTrack >= 0) { "Rendered video track is missing." }
            val videoFormat = videoExtractor.getTrackFormat(videoTrack)
            val durationUs = videoFormat.getLong(MediaFormat.KEY_DURATION)
            muxer = MediaMuxer(output.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val outVideo = muxer.addTrack(videoFormat)
            val outAudio = muxer.addTrack(audioFormat)
            muxer.start()

            fun copy(ex: MediaExtractor, sourceTrack: Int, targetTrack: Int) {
                ex.selectTrack(sourceTrack)
                val buffer = ByteBuffer.allocate(1 shl 20)
                val info = MediaCodec.BufferInfo()
                while (true) {
                    buffer.clear()
                    val size = ex.readSampleData(buffer, 0)
                    if (size < 0) break
                    val pts = ex.sampleTime
                    if (pts < 0 || pts > durationUs) break
                    info.set(0, size, pts, ex.sampleFlags)
                    muxer!!.writeSampleData(targetTrack, buffer, info)
                    if (!ex.advance()) break
                }
                ex.unselectTrack(sourceTrack)
            }
            copy(videoExtractor, videoTrack, outVideo)
            copy(audioExtractor, audioTrack, outAudio)
            muxer.stop()
            return output
        } catch (e: Exception) {
            output.delete()
            throw e
        } finally {
            runCatching { muxer?.release() }
            runCatching { audioExtractor.release() }
            runCatching { videoExtractor.release() }
        }
    }

    private fun openPhotoInputStream(uri: Uri): java.io.InputStream? {
        return if (uri.scheme == "file") {
            uri.path?.let { java.io.FileInputStream(File(it)) }
        } else {
            context.contentResolver.openInputStream(uri)
        }
    }

    private fun decodeForVideo(uri: Uri, width: Int, height: Int): Bitmap {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        val boundsStream = openPhotoInputStream(uri)
            ?: throw IllegalArgumentException("Could not read a selected photo.")
        boundsStream.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / sample > width * 2 || bounds.outHeight / sample > height * 2) sample *= 2
        val options = BitmapFactory.Options().apply { inSampleSize = sample; inPreferredConfig = Bitmap.Config.ARGB_8888 }
        return openPhotoInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, options)
        } ?: throw IllegalArgumentException("Could not decode a selected photo.")
    }

    private fun drawCover(canvas: Canvas, bitmap: Bitmap, width: Int, height: Int, zoom: Float, paint: Paint) {
        val scale = max(width.toFloat() / bitmap.width, height.toFloat() / bitmap.height) * zoom
        val drawWidth = bitmap.width * scale
        val drawHeight = bitmap.height * scale
        val left = (width - drawWidth) / 2f
        val top = (height - drawHeight) / 2f
        canvas.drawBitmap(bitmap, null, RectF(left, top, left + drawWidth, top + drawHeight), paint)
    }

    private fun drawWrapped(canvas: Canvas, value: String, x: Float, y: Float, paint: Paint, maxLines: Int) {
        if (value.isBlank()) return
        val maxWidth = 650f
        val words = value.split(Regex("\\s+"))
        val lines = mutableListOf<String>()
        var line = ""
        for (word in words) {
            val candidate = if (line.isEmpty()) word else "$line $word"
            if (paint.measureText(candidate) <= maxWidth || line.isEmpty()) line = candidate
            else { lines.add(line); line = word }
        }
        if (line.isNotEmpty()) lines.add(line)
        lines.take(maxLines).forEachIndexed { index, text ->
            canvas.drawText(text, x, y + index * (paint.textSize + 5f), paint)
        }
    }

    private object MediaCodecInfoCompat {
        const val COLOR_FORMAT_SURFACE = 0x7F000789
    }
}
