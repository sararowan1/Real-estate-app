package com.dreamxhomes.reelmaker

import android.content.Context
import android.media.*
import android.net.Uri
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.*

/** Offline AAC mixer: narration is foreground; licensed music is looped/trimmed to video duration. */
class AudioMixEngine(private val context: Context) {
    private data class Pcm(val samples: ShortArray, val rate: Int, val channels: Int)

    fun mixIntoVideo(video: File, narration: File?, music: Uri?, musicVolume: Float = 0.12f,
                     duckVolume: Float = 0.06f, onProgress: (Int) -> Unit = {}): File {
        val videoEx = MediaExtractor()
        val out = File(context.cacheDir, "dreamx_mixed_${System.currentTimeMillis()}.mp4")
        var muxer: MediaMuxer? = null
        try {
            videoEx.setDataSource(video.absolutePath)
            var videoTrack = -1
            var videoFormat: MediaFormat? = null
            for (i in 0 until videoEx.trackCount) {
                val f = videoEx.getTrackFormat(i)
                if ((f.getString(MediaFormat.KEY_MIME) ?: "").startsWith("video/")) { videoTrack = i; videoFormat = f; break }
            }
            require(videoTrack >= 0 && videoFormat != null) { "Video track missing." }
            val durationUs = videoFormat!!.getLong(MediaFormat.KEY_DURATION)
            val narrationPcm = narration?.let { decode(it.absolutePath, null) }
            val musicPcm = music?.let { decode(null, it) }
            require(narrationPcm != null || musicPcm != null) { "No audio selected." }
            val rate = 44100
            val channels = 2
            val totalFrames = ((durationUs / 1_000_000.0) * rate).toInt().coerceAtLeast(1)
            val voice = narrationPcm?.let { toStereoRate(it, rate, totalFrames, false) }
            val bed = musicPcm?.let { toStereoRate(it, rate, totalFrames, true) }
            val mixed = ShortArray(totalFrames * channels)
            val windowFrames = rate / 50 // 20 ms ducking envelope
            for (frame in 0 until totalFrames) {
                val start = (frame / windowFrames) * windowFrames
                val end = min(totalFrames, start + windowFrames)
                var rms = 0.0
                if (voice != null) {
                    var sum = 0.0
                    for (f in start until end) for (c in 0 until channels) { val v = voice[f * channels + c] / 32768.0; sum += v * v }
                    rms = sqrt(sum / max(1, (end - start) * channels))
                }
                val speaking = voice != null && rms > 0.012
                val bgGain = if (speaking) duckVolume else musicVolume
                for (c in 0 until channels) {
                    val idx = frame * channels + c
                    val v = (voice?.get(idx)?.toDouble()?.div(32768.0) ?: 0.0)
                    val b = (bed?.get(idx)?.toDouble()?.div(32768.0) ?: 0.0)
                    // 80 ms attack/release smoothing is approximated by the speech-window envelope.
                    val fadeIn = min(1.0, frame.toDouble() / (rate * 0.35))
                    val fadeOut = min(1.0, (totalFrames - frame).toDouble() / (rate * 0.65))
                    val musicGain = bgGain * min(fadeIn, fadeOut)
                    mixed[idx] = (v * 0.92 + b * musicGain).coerceIn(-0.98, 0.98).times(32767).toInt().toShort()
                }
                if (frame % (rate * 2) == 0) onProgress((frame * 35 / totalFrames).coerceIn(0, 35))
            }

            val encodedAudio = encodeAac(mixed, rate, channels, durationUs)
            val audioEx = MediaExtractor().apply { setDataSource(encodedAudio.absolutePath) }
            var aTrack = -1
            for (i in 0 until audioEx.trackCount) if ((audioEx.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: "").startsWith("audio/")) { aTrack = i; break }
            require(aTrack >= 0) { "Mixed audio encoding failed." }
            muxer = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val mux = muxer!!
            val outV = mux.addTrack(videoFormat!!)
            val outA = mux.addTrack(audioEx.getTrackFormat(aTrack))
            mux.start()
            copyTrack(videoEx, videoTrack, mux, outV, durationUs)
            copyTrack(audioEx, aTrack, mux, outA, durationUs)
            mux.stop()
            encodedAudio.delete()
            onProgress(100)
            return out
        } catch (e: Exception) {
            out.delete(); throw e
        } finally { runCatching { muxer?.release() }; runCatching { videoEx.release() } }
    }

    private fun decode(path: String?, uri: Uri?): Pcm {
        val ex = MediaExtractor()
        try {
            if (path != null) ex.setDataSource(path) else ex.setDataSource(context, uri!!, null)
            var track = -1; var format: MediaFormat? = null
            for (i in 0 until ex.trackCount) { val f = ex.getTrackFormat(i); if ((f.getString(MediaFormat.KEY_MIME) ?: "").startsWith("audio/")) { track = i; format = f; break } }
            require(track >= 0 && format != null) { "Audio file has no supported audio track." }
            ex.selectTrack(track)
            val mime = format!!.getString(MediaFormat.KEY_MIME)!!
            val decoder = MediaCodec.createDecoderByType(mime)
            decoder.configure(format, null, null, 0); decoder.start()
            val chunks = ArrayList<ShortArray>(); var total = 0; var inputDone = false; var outputDone = false
            var rate = format!!.getInteger(MediaFormat.KEY_SAMPLE_RATE); var channels = format!!.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            val info = MediaCodec.BufferInfo()
            while (!outputDone) {
                if (!inputDone) {
                    val ix = decoder.dequeueInputBuffer(10000)
                    if (ix >= 0) { val b = decoder.getInputBuffer(ix)!!; b.clear(); val n = ex.readSampleData(b, 0)
                        if (n < 0) { decoder.queueInputBuffer(ix, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inputDone = true }
                        else { decoder.queueInputBuffer(ix, 0, n, ex.sampleTime, 0); ex.advance() } }
                }
                val ox = decoder.dequeueOutputBuffer(info, 10000)
                if (ox >= 0) { val b = decoder.getOutputBuffer(ox)
                    if (b != null && info.size > 0) { val dup = b.duplicate().order(ByteOrder.LITTLE_ENDIAN); dup.position(info.offset); dup.limit(info.offset + info.size)
                        val arr = ShortArray(info.size / 2); dup.slice().order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(arr); chunks.add(arr); total += arr.size }
                    decoder.releaseOutputBuffer(ox, false); if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outputDone = true
                } else if (ox == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) { val of = decoder.outputFormat; rate = of.getInteger(MediaFormat.KEY_SAMPLE_RATE); channels = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT) }
            }
            decoder.stop(); decoder.release()
            val all = ShortArray(total); var p = 0; chunks.forEach { it.copyInto(all, p); p += it.size }
            return Pcm(all, rate, channels)
        } finally { ex.release() }
    }

    private fun toStereoRate(pcm: Pcm, targetRate: Int, targetFrames: Int, loop: Boolean): ShortArray {
        val sourceFrames = pcm.samples.size / pcm.channels
        val out = ShortArray(targetFrames * 2)
        if (sourceFrames == 0) return out
        for (i in 0 until targetFrames) {
            val rawPos = i.toDouble() * pcm.rate / targetRate
            if (!loop && rawPos >= sourceFrames) continue
            val pos = if (loop) rawPos % sourceFrames else rawPos.coerceAtMost((sourceFrames - 1).toDouble())
            val a = pos.toInt(); val b = if (loop) (a + 1) % sourceFrames else min(a + 1, sourceFrames - 1); val frac = pos - a
            fun sample(frame: Int, channel: Int): Double {
                val ch = if (pcm.channels == 1) 0 else channel.coerceAtMost(pcm.channels - 1)
                return pcm.samples[frame * pcm.channels + ch].toDouble()
            }
            for (c in 0..1) out[i * 2 + c] = (sample(a,c) * (1-frac) + sample(b,c) * frac).roundToInt().coerceIn(-32768,32767).toShort()
        }
        return out
    }

    private fun encodeAac(samples: ShortArray, rate: Int, channels: Int, durationUs: Long): File {
        val file = File(context.cacheDir, "dreamx_mix_audio_${System.currentTimeMillis()}.m4a")
        val fmt = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, rate, channels).apply { setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC); setInteger(MediaFormat.KEY_BIT_RATE, 160000); setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384) }
        val enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC); var mux: MediaMuxer? = null; var started = false; var track = -1
        try {
            enc.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE); enc.start(); val info = MediaCodec.BufferInfo(); var frame = 0; var inputDone = false; var outputDone = false
            while (!outputDone) {
                if (!inputDone) { val ix = enc.dequeueInputBuffer(10000); if (ix >= 0) { val b = enc.getInputBuffer(ix)!!; b.clear(); val maxSamples = min(b.remaining()/2, 4096); val count = min(maxSamples, samples.size-frame)
                    if (count <= 0) { enc.queueInputBuffer(ix,0,0,durationUs,MediaCodec.BUFFER_FLAG_END_OF_STREAM); inputDone = true }
                    else { for (i in 0 until count) b.putShort(samples[frame+i]); val pts = (frame.toLong()/channels)*1_000_000L/rate; enc.queueInputBuffer(ix,0,count*2,pts,0); frame += count } } }
                val ox = enc.dequeueOutputBuffer(info,10000)
                when { ox == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> { mux = MediaMuxer(file.absolutePath,MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4); track = mux!!.addTrack(enc.outputFormat); mux!!.start(); started = true }
                    ox >= 0 -> { val b = enc.getOutputBuffer(ox); if (b != null && info.size > 0 && started) { b.position(info.offset); b.limit(info.offset+info.size); mux!!.writeSampleData(track,b,info) }; enc.releaseOutputBuffer(ox,false); if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM)!=0) outputDone = true } }
            }
            mux?.stop(); return file
        } catch(e: Exception) { file.delete(); throw e } finally { runCatching { enc.stop() }; enc.release(); runCatching { mux?.release() } }
    }

    private fun copyTrack(ex: MediaExtractor, source: Int, mux: MediaMuxer, target: Int, durationUs: Long) {
        ex.selectTrack(source); val buffer = ByteBuffer.allocate(1024*1024); val info = MediaCodec.BufferInfo()
        while (true) { buffer.clear(); val size = ex.readSampleData(buffer,0); if (size < 0) break; val pts = ex.sampleTime; if (pts < 0 || pts > durationUs) break
            info.set(0,size,pts,ex.sampleFlags); mux.writeSampleData(target,buffer,info); if (!ex.advance()) break }
        ex.unselectTrack(source)
    }
}
