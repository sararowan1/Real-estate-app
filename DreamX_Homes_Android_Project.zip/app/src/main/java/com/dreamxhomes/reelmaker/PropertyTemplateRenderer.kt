package com.dreamxhomes.reelmaker

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface

/** One shared renderer for template thumbnails, live preview and the exported MP4. */
object PropertyTemplateRenderer {
    private val navy = Color.rgb(7, 28, 51)
    private val navy2 = Color.rgb(11, 42, 70)
    private val gold = Color.rgb(241, 190, 57)
    private val green = Color.rgb(48, 166, 65)
    private val white = Color.WHITE

    fun title(template: String): String = when (template) {
        "House for Rent" -> "HOUSE FOR RENT"
        "Land for Sale" -> "LAND FOR SALE"
        "Commercial Property" -> "COMMERCIAL PROPERTY FOR SALE"
        else -> "HOUSE FOR SALE"
    }

    fun draw(canvas: Canvas, width: Int, height: Int, template: String,
             location: String, price: String, bedrooms: String, bathrooms: String,
             features: String, phone: String, urgentEnabled: Boolean = false,
             urgentText: String = "URGENT SALE", urgentColor: Int = Color.RED,
             watermark: Boolean = false) {
        val sx = width / 1080f
        val sy = height / 1920f
        canvas.save()
        canvas.scale(sx, sy)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        fun rect(l: Float, t: Float, r: Float, b: Float, radius: Float, color: Int, stroke: Int? = null, sw: Float = 0f) {
            p.color = color; p.style = Paint.Style.FILL
            canvas.drawRoundRect(RectF(l,t,r,b), radius, radius, p)
            if (stroke != null) { p.color=stroke; p.style=Paint.Style.STROKE; p.strokeWidth=sw; canvas.drawRoundRect(RectF(l,t,r,b),radius,radius,p); p.style=Paint.Style.FILL }
        }
        fun text(value: String, x: Float, y: Float, size: Float, color: Int, bold: Boolean = false, align: Paint.Align = Paint.Align.CENTER) {
            p.color=color; p.textSize=size; p.textAlign=align
            p.typeface=Typeface.create("sans-serif", if (bold) Typeface.BOLD else Typeface.NORMAL)
            canvas.drawText(value, x, y, p)
        }
        // Consistent brand header across all four reel templates.
        p.color = navy; canvas.drawRect(0f,0f,1080f,142f,p)
        text("DREAMX HOMES",540f,76f,48f,white,true)
        text("R E A L   E S T A T E",540f,116f,20f,gold,true)
        p.color=gold; p.strokeWidth=5f; canvas.drawLine(0f,143f,1080f,143f,p)
        p.color=green; p.strokeWidth=5f; canvas.drawLine(820f,143f,1080f,143f,p)

        if (urgentEnabled) {
            rect(600f,170f,1040f,235f,18f,Color.rgb(30,10,12),urgentColor,3f)
            p.color=urgentColor; canvas.drawCircle(638f,202f,12f,p)
            text(urgentText.take(25),670f,213f,27f,urgentColor,true,Paint.Align.LEFT)
        }

        // Large readable information card in the lower third, matching the selected preview.
        val top = 1250f
        rect(34f,top,1046f,1880f,34f,Color.argb(245, Color.red(navy), Color.green(navy), Color.blue(navy)),gold,5f)
        val labelColor = if (template == "House for Rent" || template == "Land for Sale") green else gold
        rect(92f,top+34f,988f,top+126f,20f,labelColor)
        val heading = title(template)
        val titleSize = if (heading.length > 22) 34f else 43f
        text(heading,540f,top+94f,titleSize,if (labelColor==gold) navy else white,true)

        text(location.ifBlank { "Sri Lanka" },540f,top+196f,39f,white,true)
        val specs = when (template) {
            "Land for Sale" -> listOfNotNull(features.split(Regex("[,;\\n]")).map { it.trim() }.filter { it.isNotBlank() }.take(3).takeIf { it.isNotEmpty() }?.joinToString("  •  ") )
            "Commercial Property" -> listOfNotNull(features.split(Regex("[,;\\n]")).map { it.trim() }.filter { it.isNotBlank() }.take(3).takeIf { it.isNotEmpty() }?.joinToString("  •  "), bedrooms.takeIf { it.isNotBlank() }?.let { "$it Storeys" })
            else -> listOfNotNull(bedrooms.takeIf { it.isNotBlank() }?.let { "$it Bedrooms" }, bathrooms.takeIf { it.isNotBlank() }?.let { "$it Bathrooms" })
        }
        var y = top + 270f
        specs.take(2).forEach { line -> text(line.take(48),540f,y,29f,white,true); y += 55f }
        val featureLines = features.split(Regex("[,;\\n]")).map { it.trim() }.filter { it.isNotBlank() }
            .filterNot { candidate -> specs.any { it.contains(candidate, ignoreCase=true) } }.take(3)
        featureLines.forEach { item ->
            text("✓  ${item.take(48)}",540f,y,25f,Color.rgb(226,238,229),false); y += 43f
        }
        val priceTop = 1650f
        rect(115f,priceTop,965f,priceTop+105f,22f,gold)
        text(price.ifBlank { "Price on request" }.take(34),540f,priceTop+68f,42f,navy,true)
        rect(180f,1780f,900f,1860f,28f,navy2,green,3f)
        text("CALL / WHATSAPP  ${phone.ifBlank { "0750876292" }}",540f,1832f,29f,white,true)
        if (watermark) {
            p.color=Color.argb(100, Color.red(white), Color.green(white), Color.blue(white)); p.textSize=30f; p.textAlign=Paint.Align.CENTER
            p.typeface=Typeface.create("sans-serif",Typeface.BOLD); canvas.drawText("DreamX Homes",540f,900f,p)
        }
        canvas.restore()
    }
}
