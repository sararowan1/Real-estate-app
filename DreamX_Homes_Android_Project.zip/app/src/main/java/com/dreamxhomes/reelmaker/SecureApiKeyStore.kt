package com.dreamxhomes.reelmaker

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Encrypts the user's own Azure Speech subscription key at rest with an Android Keystore AES key. */
class SecureApiKeyStore(context: Context) {
    private val prefs = context.getSharedPreferences("dreamx_secure_settings", Context.MODE_PRIVATE)
    private val alias = "dreamx_cloud_tts_key_v1"

    fun save(value: String) {
        require(value.isNotBlank()) { "API key cannot be empty." }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
        val encrypted = cipher.doFinal(value.trim().toByteArray(Charsets.UTF_8))
        prefs.edit()
            .putString("key_iv", Base64.encodeToString(cipher.iv, Base64.NO_WRAP))
            .putString("key_data", Base64.encodeToString(encrypted, Base64.NO_WRAP))
            .apply()
    }

    fun read(): String? = runCatching {
        val iv = Base64.decode(prefs.getString("key_iv", null), Base64.NO_WRAP)
        val data = Base64.decode(prefs.getString("key_data", null), Base64.NO_WRAP)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), GCMParameterSpec(128, iv))
        String(cipher.doFinal(data), Charsets.UTF_8)
    }.getOrNull()

    fun saveRegion(region: String) {
        require(region.matches(Regex("[a-z0-9-]{3,40}"))) { "Enter a valid Azure Speech region, for example southeastasia." }
        prefs.edit().putString("azure_region", region.trim()).apply()
    }

    fun readRegion(): String = prefs.getString("azure_region", "southeastasia") ?: "southeastasia"

    fun clear() {
        prefs.edit().remove("key_iv").remove("key_data").remove("azure_region").apply()
    }

    private fun getOrCreateKey(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (store.getKey(alias, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(KeyGenParameterSpec.Builder(alias,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setRandomizedEncryptionRequired(true)
            .build())
        return generator.generateKey()
    }
}
