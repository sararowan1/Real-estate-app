package com.dreamxhomes.reelmaker

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.media.MediaPlayer
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.provider.MediaStore
import android.os.Handler
import android.os.Looper
import android.os.Environment
import java.io.File
import java.io.FileInputStream
import java.io.OutputStream
import java.util.concurrent.Executors
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import java.util.Locale

class MainActivity : ComponentActivity() {
    private val photos = mutableListOf<Uri>()
    private lateinit var photoCount: TextView
    private lateinit var photoStrip: LinearLayout
    private lateinit var location: EditText
    private lateinit var price: EditText
    private lateinit var phone: EditText
    private lateinit var beds: EditText
    private lateinit var baths: EditText
    private lateinit var features: EditText
    private lateinit var script: EditText
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val exportExecutor = Executors.newSingleThreadExecutor()
    private var exportedVideo: Uri? = null
    // The preview and Gallery export share this exact final-quality MP4.
    private var preparedReelFile: File? = null
    private var preparedReelFingerprint: String? = null
    private var musicUri: Uri? = null
    private var narrationVolume: Float = 1.0f
    private var musicVolume: Float = 0.12f
    private val secureKeyStore by lazy { SecureApiKeyStore(this) }
    private var previewPlayer: MediaPlayer? = null
    private var backgroundMusicPreviewPlayer: MediaPlayer? = null
    private var musicRemoveButton: Button? = null
    private val previewExecutor = Executors.newSingleThreadExecutor()
    private val previewHandler = Handler(Looper.getMainLooper())

    private val pickPhotos = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            result.data?.clipData?.let { clip ->
                for (i in 0 until clip.itemCount) {
                    if (photos.size < 15) {
                        val uri = clip.getItemAt(i).uri
                        runCatching { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                        photos.add(uri)
                    }
                }
            } ?: result.data?.data?.let {
                if (photos.size < 15) {
                    runCatching { contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                    photos.add(it)
                }
            }
            refreshSelectedPhotos()
        }
    }


    private val pickMusic = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            result.data?.data?.let { uri ->
                runCatching { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                stopBackgroundMusicPreview()
                musicUri = uri
                refreshMusicSelection()
            }
        }
    }
    private var musicStatus: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(20,34,29)
        window.navigationBarColor = android.graphics.Color.rgb(20,34,29)
        // Load the supplied luxury sample track as the default selectable background music.
        runCatching {
            val sample = File(cacheDir, "dreamx_luxury_sample.mp3")
            if (!sample.exists()) assets.open("danyvin-this-is-luxury-real-estate-634726.mp3").use { input ->
                sample.outputStream().use { output -> input.copyTo(output) }
            }
            musicUri = Uri.fromFile(sample)
        }
        buildScreen()
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val result = tts?.setLanguage(Locale("si", "LK"))
                ttsReady = result != TextToSpeech.LANG_MISSING_DATA &&
                    result != TextToSpeech.LANG_NOT_SUPPORTED
            }
        }
    }

    private fun buildScreen() {
        val scroll = ScrollView(this)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 36, 40, 48)
            setBackgroundColor(android.graphics.Color.rgb(247,245,239))
        }
        scroll.addView(col)
        setContentView(scroll)

        val brand = TextView(this).apply {
            text = "DREAMX HOMES\nPROPERTY REEL MAKER"
            textSize = 25f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.rgb(181,139,69))
            setPadding(0, 8, 0, 24)
            typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD)
        }
        col.addView(brand)
        addLabel(col, "Create a luxury property reel")
        val pick = Button(this).apply { text = "SELECT PROPERTY PHOTOS" }
        col.addView(pick, match())
        photoCount = addLabel(col, "No photos selected")
        photoStrip = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 4, 0, 8)
        }
        val photoScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = true
            addView(photoStrip)
        }
        col.addView(photoScroll, match())
        pick.setOnClickListener {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                type = "image/*"; putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                addCategory(Intent.CATEGORY_OPENABLE)
            }
            pickPhotos.launch(intent)
        }

        location = addField(col, "Property location", "e.g. Nugegoda")
        price = addField(col, "Price", "e.g. Rs. 75 Million")
        phone = addField(col, "Contact number", "e.g. 075 087 6292")
        beds = addField(col, "Bedrooms", "e.g. 5")
        baths = addField(col, "Bathrooms", "e.g. 5")
        features = addField(col, "Main features", "Modern pantry, rooftop, parking")

        val makeScript = Button(this).apply { text = "GENERATE SINHALA SCRIPT" }
        col.addView(makeScript, match())
        script = EditText(this).apply {
            hint = "Generated Sinhala narration will appear here. You can edit it."
            minLines = 5; gravity = Gravity.TOP
            setTextSize(16f)
        }
        col.addView(script, match())
        makeScript.setOnClickListener { script.setText(createSinhalaScript()) }

        val voiceSettings = Button(this).apply { text = "SET UP GEMINI MALE AI VOICE (CHARON)" }
        col.addView(voiceSettings, match())
        voiceSettings.setOnClickListener { showGeminiKeyDialog() }

        val speak = Button(this).apply { text = "PREVIEW SINHALA VOICE" }
        col.addView(speak, match())
        speak.setOnClickListener {
            val text = script.text.toString().trim()
            if (text.isEmpty()) {
                toast("Please generate or enter a Sinhala script first.")
            } else {
                val key = secureKeyStore.read()
                if (!key.isNullOrBlank()) {
                    speak.isEnabled = false
                    speak.text = "GENERATING MALE AI VOICE..."
                    previewExecutor.execute {
                        try {
                            val wav = File(cacheDir, "dreamx_charon_preview.wav")
                            GeminiAchirdTts().synthesizeToWav(key, text, wav)
                            runOnUiThread {
                                previewPlayer?.release()
                                previewPlayer = MediaPlayer().apply {
                                    setDataSource(wav.absolutePath)
                                    setOnPreparedListener { it.start(); speak.isEnabled = true; speak.text = "PREVIEW SINHALA VOICE" }
                                    setOnCompletionListener { it.release(); previewPlayer = null; wav.delete() }
                                    setOnErrorListener { player, _, _ -> player.release(); previewPlayer = null; speak.isEnabled = true; speak.text = "PREVIEW SINHALA VOICE"; toast("Could not play voice preview."); true }
                                    prepareAsync()
                                }
                            }
                        } catch (e: Exception) {
                            runOnUiThread {
                                speak.isEnabled = true; speak.text = "PREVIEW SINHALA VOICE"
                                toast("Gemini male voice preview failed: ${e.message}. Check the API key, quota and internet connection.")
                            }
                        }
                    }
                } else toast("Set up the Gemini API key to use the selected male AI narrator voice.")
            }
        }

        val previewReel = Button(this).apply { text = "PREVIEW REEL" }
        col.addView(previewReel, match())
        previewReel.setOnClickListener { showReelPreview() }

        val generateReel = Button(this).apply { text = "GENERATE REEL" }
        col.addView(generateReel, match())
        generateReel.setOnClickListener { startVideoExport(generateReel) }

        val musicButton = Button(this).apply { text = "SELECT / CHANGE BACKGROUND MUSIC" }
        col.addView(musicButton, match())
        val musicRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        musicStatus = TextView(this).apply {
            textSize = 14f
            setTextColor(android.graphics.Color.rgb(35,45,39))
            setPadding(0, 10, 8, 10)
        }
        musicRow.addView(musicStatus, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        musicRemoveButton = Button(this).apply {
            text = "X"
            contentDescription = "Remove selected background music"
            setOnClickListener {
                stopBackgroundMusicPreview()
                musicUri = null
                refreshMusicSelection()
                invalidatePreparedReel()
            }
        }
        musicRow.addView(musicRemoveButton, LinearLayout.LayoutParams(dp(52), dp(48)))
        col.addView(musicRow, match())
        refreshMusicSelection()
        val musicPreviewButton = Button(this).apply { text = "PREVIEW SELECTED MUSIC" }
        col.addView(musicPreviewButton, match())
        musicPreviewButton.setOnClickListener { startBackgroundMusicPreview() }
        musicButton.setOnClickListener {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                type = "audio/*"
                addCategory(Intent.CATEGORY_OPENABLE)
            }
            pickMusic.launch(intent)
        }

        addLabel(col, "AUDIO MIXER — ADJUST BEFORE PREVIEW")
        val voiceValue = addLabel(col, "Narrator volume: 100%")
        val voiceSlider = SeekBar(this).apply {
            max = 100
            progress = (narrationVolume * 100).toInt()
        }
        voiceSlider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                narrationVolume = progress / 100f
                voiceValue.text = "Narrator volume: $progress%"
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        col.addView(voiceSlider, match())
        val musicValue = addLabel(col, "Background music volume: 12%")
        val musicSlider = SeekBar(this).apply {
            max = 100
            progress = (musicVolume * 100).toInt()
        }
        musicSlider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                musicVolume = progress / 100f
                backgroundMusicPreviewPlayer?.setVolume(musicVolume, musicVolume)
                musicValue.text = "Background music volume: $progress%"
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        col.addView(musicSlider, match())

        addLabel(col, "Brand name: DreamX Homes  ·  Watermark + property details + end card")
        addLabel(col, "Video style: Vertical 9:16 · cinematic slow zoom · smooth fades")
        addLabel(col, "Output: MP4 video saved to Gallery and ready to share")
        addLabel(col, "Audio Studio: synchronized narrator + background music with adjustable separate volume controls. Music starts with the narrator and loops/trims to the full video duration. Choose licensed music or your own audio.")
    }

    private fun refreshMusicSelection() {
        val uri = musicUri
        musicStatus?.text = if (uri == null) "No background music selected" else {
            val name = runCatching {
                contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                    if (c.moveToFirst()) c.getString(0) else null
                }
            }.getOrNull() ?: uri.lastPathSegment ?: "Selected music"
            "♫  $name"
        }
        musicRemoveButton?.visibility = if (uri == null) android.view.View.GONE else android.view.View.VISIBLE
    }

    private fun stopBackgroundMusicPreview() {
        runCatching { backgroundMusicPreviewPlayer?.stop() }
        runCatching { backgroundMusicPreviewPlayer?.release() }
        backgroundMusicPreviewPlayer = null
    }

    private fun startBackgroundMusicPreview() {
        val uri = musicUri
        if (uri == null) { toast("Select a background music track first."); return }
        stopBackgroundMusicPreview()
        try {
            backgroundMusicPreviewPlayer = MediaPlayer().apply {
                setDataSource(this@MainActivity, uri)
                isLooping = true
                setVolume(musicVolume, musicVolume)
                setOnPreparedListener { it.start(); toast("Selected background music is playing.") }
                setOnErrorListener { player, _, _ ->
                    player.release(); backgroundMusicPreviewPlayer = null
                    toast("Could not preview this music file. Try MP3 or M4A.")
                    true
                }
                prepareAsync()
            }
        } catch (e: Exception) {
            stopBackgroundMusicPreview()
            toast("Music preview failed: ${e.message}")
        }
    }

    private fun invalidatePreparedReel() {
        preparedReelFile?.delete()
        preparedReelFile = null
        preparedReelFingerprint = null
    }

    private fun audioDurationMs(file: File): Long {
        val retriever = android.media.MediaMetadataRetriever()
        return try {
            retriever.setDataSource(file.absolutePath)
            retriever.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } finally { retriever.release() }
    }

    private fun showReelPreview() {
        if (photos.isEmpty()) {
            toast("Please select property photos first.")
            return
        }
        val dark = android.graphics.Color.rgb(20, 34, 29)
        val gold = android.graphics.Color.rgb(215, 181, 109)
        val photoUris = photos.toList()
        val details = ReelVideoExporter.Details(
            location = location.text.toString().trim(),
            price = price.text.toString().trim(),
            bedrooms = beds.text.toString().trim(),
            bathrooms = baths.text.toString().trim(),
            features = features.text.toString().trim(),
            phone = phone.text.toString().trim(),
            narration = script.text.toString().trim()
        )

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(12, 12, 12, 12)
            setBackgroundColor(dark)
        }
        val title = TextView(this).apply {
            text = "DREAMX HOMES — QUICK REEL PREVIEW"
            textSize = 17f
            gravity = Gravity.CENTER
            setTextColor(gold)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(0, 8, 0, 12)
        }
        root.addView(title, match())

        // Instant, photo-backed preview: do not wait for a full 1080p encode just to show images.
        // The slide order and 2-second photo / 5-second looping end-card timing mirror the exporter.
        val stage = android.widget.FrameLayout(this).apply {
            setBackgroundColor(android.graphics.Color.BLACK)
        }
        val image = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(android.graphics.Color.BLACK)
        }
        stage.addView(image, android.widget.FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        ))
        // Switch to the completed MP4 for an audio/video-identical preview.
        val finalVideoPreview = android.widget.VideoView(this).apply {
            visibility = android.view.View.GONE
            setBackgroundColor(android.graphics.Color.BLACK)
        }
        stage.addView(finalVideoPreview, android.widget.FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        ))
        val brand = TextView(this).apply {
            text = "DREAMX HOMES"
            textSize = 17f
            gravity = Gravity.CENTER
            setTextColor(gold)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setBackgroundColor(android.graphics.Color.argb(155, 7, 19, 15))
        }
        stage.addView(brand, android.widget.FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(42), Gravity.TOP
        ))
        val cta = TextView(this).apply {
            text = "⌂  DREAMX HOMES\n\nFOLLOW US FOR MORE\nPROPERTIES  •  LANDS  •  RENTALS\nNew listings and latest property updates\nFollow DreamX Homes"
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.WHITE)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(12, 18, 12, 18)
            setBackgroundColor(android.graphics.Color.argb(220, 3, 31, 21))
            visibility = android.view.View.GONE
        }
        stage.addView(cta, android.widget.FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM
        ))
        root.addView(stage, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        val status = TextView(this).apply {
            text = "Quick preview is starting… Final 1080p video is rendering in the background."
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.WHITE)
            setPadding(8, 10, 8, 8)
        }
        root.addView(status, match())
        val progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
        }
        root.addView(progress, match())
        val replay = Button(this).apply { text = "REPLAY PREVIEW" }
        root.addView(replay, match())

        val dialog = android.app.AlertDialog.Builder(this)
            .setView(root)
            .setNegativeButton("CLOSE", null)
            .create()
        var previewRunning = true
        var finalVideoReady = false
        var slideIndex = 0
        var inEndCard = false
        var endCardStartedAt = 0L
        var loadToken = 0
        val slideHandler = Handler(Looper.getMainLooper())
        val slideTask = object : Runnable {
            override fun run() {
                if (!previewRunning || !dialog.isShowing) return
                val now = android.os.SystemClock.elapsedRealtime()
                if (!inEndCard && slideIndex >= photoUris.size) {
                    inEndCard = true
                    endCardStartedAt = now
                }
                if (inEndCard && now - endCardStartedAt >= 5_000L) {
                    inEndCard = false
                    slideIndex = 0
                }
                val index = if (inEndCard) {
                    ((now - endCardStartedAt) / 2_000L).toInt() % photoUris.size
                } else slideIndex
                cta.visibility = if (inEndCard) android.view.View.VISIBLE else android.view.View.GONE
                val token = ++loadToken
                previewExecutor.execute {
                    try {
                        val bitmap = decodePreviewBitmap(photoUris[index])
                        runOnUiThread {
                            if (previewRunning && dialog.isShowing && token == loadToken) {
                                image.setImageBitmap(bitmap)
                                status.text = if (inEndCard) "Final 5 seconds — photos loop behind the DreamX Homes follow message." else "Showing photo ${index + 1} of ${photoUris.size}"
                            } else bitmap.recycle()
                        }
                    } catch (e: Exception) {
                        runOnUiThread {
                            if (dialog.isShowing) status.text = "Could not load photo ${index + 1}: ${e.message}"
                        }
                    }
                }
                if (!inEndCard) slideIndex++
                slideHandler.postDelayed(this, 2_000L)
            }
        }
        dialog.setOnDismissListener {
            previewRunning = false
            slideHandler.removeCallbacks(slideTask)
            image.setImageDrawable(null)
            runCatching { finalVideoPreview.stopPlayback() }
            previewPlayer?.release()
            previewPlayer = null
            stopBackgroundMusicPreview()
        }
        dialog.show()
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.window?.setLayout(
            (resources.displayMetrics.widthPixels * 0.94).toInt(),
            (resources.displayMetrics.heightPixels * 0.88).toInt()
        )
        replay.setOnClickListener {
            if (finalVideoReady) {
                finalVideoPreview.seekTo(0)
                finalVideoPreview.start()
                return@setOnClickListener
            }
            slideIndex = 0
            inEndCard = false
            endCardStartedAt = 0L
            slideHandler.removeCallbacks(slideTask)
            slideTask.run()
        }
        slideTask.run()
        if (musicUri != null) startBackgroundMusicPreview()

        // Render the real high-quality MP4 concurrently. The quick preview above remains visible
        // immediately, instead of leaving a black VideoView on screen for the entire render.
        exportExecutor.execute {
            try {
                val rendered = prepareFinalReel(photoUris, details) { phase, percent ->
                    runOnUiThread {
                        if (dialog.isShowing) {
                            progress.progress = percent
                            status.text = "$phase — $percent%"
                        }
                    }
                }
                runOnUiThread {
                    if (dialog.isShowing && previewRunning) {
                        finalVideoReady = true
                        slideHandler.removeCallbacks(slideTask)
                        stopBackgroundMusicPreview()
                        image.visibility = android.view.View.GONE
                        finalVideoPreview.visibility = android.view.View.VISIBLE
                        finalVideoPreview.setVideoPath(rendered.absolutePath)
                        finalVideoPreview.setOnPreparedListener {
                            finalVideoPreview.start()
                            status.text = "Playing final MP4 preview — narration and music are included."
                        }
                        finalVideoPreview.setOnCompletionListener {
                            status.text = "Preview finished. Tap REPLAY PREVIEW to watch again."
                        }
                        finalVideoPreview.setOnErrorListener { _, what, extra ->
                            status.text = "Final MP4 preview playback failed ($what/$extra). Use GENERATE REEL to save the file."
                            true
                        }
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    if (dialog.isShowing) status.text = "Quick preview is playing. Final render failed: ${e.message ?: e.javaClass.simpleName}"
                }
            }
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun decodePreviewBitmap(uri: Uri): android.graphics.Bitmap {
        val bounds = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "Cannot open selected photo." }
            android.graphics.BitmapFactory.decodeStream(input, null, bounds)
        }
        val sample = maxOf(1, Integer.highestOneBit(maxOf(bounds.outWidth / 720, bounds.outHeight / 1280)))
        val options = android.graphics.BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = android.graphics.Bitmap.Config.RGB_565
        }
        return contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "Cannot read selected photo." }
            requireNotNull(android.graphics.BitmapFactory.decodeStream(input, null, options)) {
                "Selected image could not be decoded."
            }
        }
    }

    /**
     * Creates the single final-quality MP4 used by both Preview and Generate Reel.
     * If the user has not changed any inputs since previewing, export reuses the
     * already-rendered MP4 instead of rendering a second, potentially different reel.
     */
    private fun prepareFinalReel(
        photoUris: List<Uri>,
        details: ReelVideoExporter.Details,
        onProgress: (String, Int) -> Unit
    ): File {
        val selectedMusic = musicUri
        val voiceGain = narrationVolume
        val musicGain = musicVolume
        val fingerprint = listOf(
            photoUris.joinToString("|") { it.toString() },
            details.location, details.price, details.bedrooms, details.bathrooms,
            details.features, details.phone, details.narration,
            selectedMusic?.toString().orEmpty(), voiceGain.toString(), musicGain.toString()
        ).joinToString("\u001f").toByteArray(Charsets.UTF_8).let { bytes ->
            java.security.MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { b -> "%02x".format(b) }
        }
        val cached = preparedReelFile
        if (cached != null && cached.exists() && cached.length() > 0 && preparedReelFingerprint == fingerprint) {
            onProgress("Using the exact MP4 already rendered for preview", 100)
            return cached
        }

        var narrationAudio: File? = null
        try {
            onProgress("Preparing audio and video export", 2)
            val narrationText = details.narration.trim()
            if (narrationText.isNotBlank()) {
                onProgress("Generating selected Gemini male narrator voice", 5)
                val savedKey = secureKeyStore.read()
                narrationAudio = if (!savedKey.isNullOrBlank()) {
                    val wav = File(cacheDir, "dreamx_narration_${System.currentTimeMillis()}.wav")
                    try {
                        GeminiAchirdTts().synthesizeToWav(savedKey, narrationText, wav)
                        SinhalaNarrationGenerator(this).encodeExternalWavToAac(wav)
                    } catch (e: Exception) {
                        throw IllegalStateException("Gemini male voice generation failed. Check the API key, quota and internet connection. The app did not switch to a female phone voice. Details: ${e.message}", e)
                    } finally { wav.delete() }
                } else {
                    throw IllegalStateException("Add your Gemini API key in Voice Settings to use the selected male AI narrator voice. Phone voices are disabled to prevent an unexpected female voice.")
                }
            }
            val narrationDuration = narrationAudio?.let { audioDurationMs(it) } ?: 0L
            onProgress("Rendering video until narration finishes", 12)
            val silentMp4 = ReelVideoExporter(this).export(photoUris, details, narrationDuration) { percent ->
                onProgress("Rendering final-quality video", 12 + (percent * 0.53f).toInt())
            }
            val finalFile = if (narrationAudio != null || selectedMusic != null) {
                onProgress("Mixing narrator and background music", 75)
                AudioMixEngine(this).mixIntoVideo(
                    silentMp4, narrationAudio, selectedMusic,
                    musicVolume = musicGain,
                    voiceVolume = voiceGain,
                    duckVolume = minOf(musicGain, 0.055f)
                ) { percent -> onProgress("Mixing narrator and background music", 75 + (percent * 0.24f).toInt()) }
            } else silentMp4
            preparedReelFile?.takeIf { it != finalFile }?.delete()
            preparedReelFile = finalFile
            preparedReelFingerprint = fingerprint
            onProgress("Final MP4 is ready", 100)
            return finalFile
        } finally {
            narrationAudio?.delete()
        }
    }

    private fun refreshSelectedPhotos() {
        photoCount.text = "${photos.size} / 15 photos selected"
        photoStrip.removeAllViews()
        photos.toList().forEachIndexed { index, uri ->
            val tile = FrameLayout(this).apply {
                setBackgroundColor(android.graphics.Color.rgb(20, 34, 29))
            }
            val thumb = ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                val side = (resources.displayMetrics.density * 92).toInt()
                layoutParams = FrameLayout.LayoutParams(side, side)
                runCatching {
                    contentResolver.openInputStream(uri)?.use { input ->
                        setImageBitmap(android.graphics.BitmapFactory.decodeStream(input))
                    }
                }
            }
            tile.addView(thumb)
            val remove = TextView(this).apply {
                text = "×"
                textSize = 20f
                gravity = Gravity.CENTER
                setTextColor(android.graphics.Color.WHITE)
                setBackgroundColor(android.graphics.Color.rgb(190, 35, 45))
                val size = (resources.displayMetrics.density * 28).toInt()
                layoutParams = FrameLayout.LayoutParams(size, size, Gravity.TOP or Gravity.END)
                setOnClickListener {
                    photos.removeAt(index)
                    refreshSelectedPhotos()
                }
            }
            tile.addView(remove)
            val params = LinearLayout.LayoutParams(
                (resources.displayMetrics.density * 92).toInt(),
                (resources.displayMetrics.density * 92).toInt()
            ).apply { marginEnd = (resources.displayMetrics.density * 8).toInt() }
            photoStrip.addView(tile, params)
        }
    }

    private fun startVideoExport(button: Button) {
        if (photos.isEmpty()) {
            toast("Please select property photos first.")
            return
        }
        if (location.text.isNullOrBlank() && price.text.isNullOrBlank()) {
            toast("Please enter at least the property location or price.")
            return
        }
        val photoUris = photos.toList()
        val details = ReelVideoExporter.Details(
            location = location.text.toString().trim(),
            price = price.text.toString().trim(),
            bedrooms = beds.text.toString().trim(),
            bathrooms = baths.text.toString().trim(),
            features = features.text.toString().trim(),
            phone = phone.text.toString().trim(),
            narration = script.text.toString().trim()
        )
        button.isEnabled = false
        button.text = "GENERATING REEL..."
        val progressText = TextView(this).apply {
            textSize = 15f
            setPadding(24, 12, 24, 8)
            text = "Preparing your reel..."
        }
        val progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            isIndeterminate = false
            max = 100
            progress = 0
            setPadding(24, 8, 24, 8)
        }
        val progressLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 8, 12, 12)
            addView(progressText, match())
            addView(progressBar, match())
        }
        val estimatedSeconds = (photoUris.size * 2.0 + 3.0 +
            details.narration.trim().split(Regex("\\s+")).size / 3.5 + 8.0).toInt().coerceAtLeast(10)
        val startedAt = System.currentTimeMillis()
        val dialog = android.app.AlertDialog.Builder(this)
            .setTitle("Creating your property reel")
            .setView(progressLayout)
            .setCancelable(false)
            .create()
        dialog.show()
        progressBar.progress = 1
        progressText.text = "Starting export… 1%\nElapsed: 0s · Estimated time: about $estimatedSeconds seconds"
        var currentPhase = "Preparing export"
        val etaTicker = object : Runnable {
            override fun run() {
                if (!dialog.isShowing) return
                val elapsed = ((System.currentTimeMillis() - startedAt) / 1000L).toInt()
                val remaining = (estimatedSeconds - elapsed).coerceAtLeast(0)
                progressText.text = "$currentPhase  ${progressBar.progress}%\\nElapsed: ${elapsed}s  ·  Estimated remaining: ${remaining}s"
                previewHandler.postDelayed(this, 1000L)
            }
        }
        previewHandler.post(etaTicker)

        fun updateProgress(percent: Int, phase: String) {
            currentPhase = phase
            progressBar.progress = percent.coerceIn(0, 100)
            val elapsed = ((System.currentTimeMillis() - startedAt) / 1000L).toInt()
            val remaining = (estimatedSeconds - elapsed).coerceAtLeast(0)
            progressText.text = "$phase  ${progressBar.progress}%\\nElapsed: ${elapsed}s  ·  Estimated remaining: ${remaining}s"
        }

        exportExecutor.execute {
            try {
                val finalMp4 = prepareFinalReel(photoUris, details) { phase, percent ->
                    runOnUiThread { updateProgress(percent, phase) }
                }
                runOnUiThread { updateProgress(98, "Saving MP4 to Gallery") }
                val saved = saveVideoToGallery(finalMp4)
                runOnUiThread {
                    updateProgress(100, "Completed")
                    previewHandler.removeCallbacks(etaTicker)
                    dialog.dismiss()
                    button.isEnabled = true
                    button.text = "GENERATE REEL"
                    exportedVideo = saved
                    android.app.AlertDialog.Builder(this@MainActivity)
                        .setTitle("Your Reel is ready!")
                        .setMessage("MP4 saved to Gallery in Movies/DreamX Homes. Share it now?")
                        .setNegativeButton("CLOSE", null)
                        .setNeutralButton("DOWNLOAD") { _, _ ->
                            exportExecutor.execute {
                                try {
                                    val downloaded = copyVideoToDownloads(saved)
                                    runOnUiThread { toast("Downloaded to Downloads/DreamX Homes") }
                                } catch (downloadError: Exception) {
                                    runOnUiThread {
                                        toast("Download failed: ${downloadError.message ?: downloadError.javaClass.simpleName}")
                                    }
                                }
                            }
                        }
                        .setPositiveButton("SHARE") { _, _ -> shareVideo(saved) }
                        .show()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    previewHandler.removeCallbacks(etaTicker)
                    dialog.dismiss()
                    button.isEnabled = true
                    button.text = "GENERATE REEL"
                    toast("Export failed (${e.javaClass.simpleName}): ${e.message ?: "No error details. Check phone storage and TTS settings."}")
                }
            }
        }
    }

    private fun saveVideoToGallery(source: File): Uri {
        val values = android.content.ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "DreamX_Homes_${System.currentTimeMillis()}.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "${Environment.DIRECTORY_MOVIES}/DreamX Homes")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("Could not create Gallery video entry")
        try {
            contentResolver.openOutputStream(uri)?.use { out ->
                FileInputStream(source).use { input -> input.copyTo(out) }
            } ?: throw IllegalStateException("Could not write video to Gallery")
            values.clear()
            values.put(MediaStore.Video.Media.IS_PENDING, 0)
            contentResolver.update(uri, values, null, null)
            return uri
        } catch (e: Exception) {
            contentResolver.delete(uri, null, null)
            throw e
        }
    }

    private fun copyVideoToDownloads(sourceUri: Uri): Uri {
        val values = android.content.ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "DreamX_Homes_${System.currentTimeMillis()}.mp4")
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/DreamX Homes")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val destination = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("Could not create a Downloads entry")
        try {
            val input = contentResolver.openInputStream(sourceUri)
                ?: throw IllegalStateException("Could not read the generated Reel")
            val output = contentResolver.openOutputStream(destination)
                ?: throw IllegalStateException("Could not write the Reel to Downloads")
            input.use { src -> output.use { dst -> src.copyTo(dst) } }
            val ready = android.content.ContentValues().apply {
                put(MediaStore.MediaColumns.IS_PENDING, 0)
            }
            contentResolver.update(destination, ready, null, null)
            return destination
        } catch (e: Exception) {
            contentResolver.delete(destination, null, null)
            throw e
        }
    }

    private fun shareVideo(uri: Uri) {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "video/mp4"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, "Share DreamX Homes Reel"))
    }

    private fun showGeminiKeyDialog() {
        val input = EditText(this).apply {
            hint = "Paste your Google AI Studio API key"
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(secureKeyStore.read().orEmpty())
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 12, 28, 4)
            addView(input, match())
            addView(TextView(this@MainActivity).apply {
                text = "Selected narrator: Gemini Charon (male voice). Create a key at aistudio.google.com/api-keys. It is encrypted at rest with Android Keystore. A key stored on a phone is still extractable by a sufficiently capable attacker; for a public commercial release, use a private backend instead. Gemini free-tier use is quota-limited and Google may use free-tier content to improve its products."
                textSize = 12f
            }, match())
        }
        android.app.AlertDialog.Builder(this)
            .setTitle("Gemini Male AI Voice Setup")
            .setView(content)
            .setPositiveButton("SAVE KEY") { _, _ ->
                runCatching { secureKeyStore.save(input.text.toString()) }
                    .onSuccess { toast("Gemini male voice key saved securely on this phone.") }
                    .onFailure { toast("Could not save API key: ${it.message}") }
            }
            .setNeutralButton("REMOVE KEY") { _, _ -> secureKeyStore.clear(); toast("AI voice key removed.") }
            .setNegativeButton("CANCEL", null)
            .show()
    }

    private fun createSinhalaScript(): String {
        val loc = location.text.toString().ifBlank { "අලංකාර ස්ථානයක" }
        val p = price.text.toString().ifBlank { "මිල විමසන්න" }
        val b = beds.text.toString().ifBlank { "—" }
        val ba = baths.text.toString().ifBlank { "—" }
        val f = features.text.toString().ifBlank { "නවීන පහසුකම් රැසකින් සමන්විතයි" }
        // Write this as spoken Sinhala, not a compressed classified-ad sentence.
        // Short, natural sentences give the TTS engine room for human-like phrasing.
        return "$loc ප්‍රදේශයෙන්, ඔබේ පවුලට ගැළපෙන නිවසක් සොයනවාද? " +
            "එහෙනම් මේ නිවස ගැන ටිකක් දැනගනිමු. " +
            "නිදන කාමර $b ක් සහ නාන කාමර $ba ක් මෙහි තියෙනවා. " +
            "$f. " +
            "මෙහි අපේක්ෂිත මිල $p. " +
            "වැඩි විස්තර දැනගන්න, නැත්නම් නිවස නැරඹීමට වේලාවක් වෙන් කරගන්න, DreamX Homes අමතන්න."
    }

    private fun addLabel(parent: LinearLayout, value: String): TextView {
        val t = TextView(this).apply {
            text = value; textSize = 16f
            setTextColor(android.graphics.Color.rgb(35,45,39))
            setPadding(0, 18, 0, 10)
        }
        parent.addView(t, match())
        return t
    }

    private fun addField(parent: LinearLayout, label: String, hintText: String): EditText {
        addLabel(parent, label)
        return EditText(this).apply {
            hint = hintText; textSize = 16f
            setSingleLine(true)
            parent.addView(this, match())
        }
    }

    private fun match() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = 10 }

    private fun toast(message: String) =
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    override fun onDestroy() {
        tts?.stop(); tts?.shutdown()
        previewPlayer?.release(); previewPlayer = null
        stopBackgroundMusicPreview()
        previewExecutor.shutdown()
        exportExecutor.shutdown()
        super.onDestroy()
    }
}
