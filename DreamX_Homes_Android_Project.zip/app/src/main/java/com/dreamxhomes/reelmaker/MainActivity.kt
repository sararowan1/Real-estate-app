package com.dreamxhomes.reelmaker

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.provider.MediaStore
import android.os.Handler
import android.os.Looper
import android.os.Environment
import java.io.File
import java.io.FileInputStream
import java.io.OutputStream
import java.util.concurrent.Executors
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import java.util.Locale

class MainActivity : ComponentActivity() {
    private val photos = mutableListOf<Uri>()
    private lateinit var photoCount: TextView
    private lateinit var photoStrip: LinearLayout
    private lateinit var location: EditText
    private lateinit var price: EditText
    private lateinit var phone: EditText
    private lateinit var beds: EditText
    private lateinit var baths: EditText
    private lateinit var features: EditText
    private lateinit var script: EditText
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val exportExecutor = Executors.newSingleThreadExecutor()
    private var exportedVideo: Uri? = null
    private var musicUri: Uri? = null
    private val previewHandler = Handler(Looper.getMainLooper())

    private val pickPhotos = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            result.data?.clipData?.let { clip ->
                for (i in 0 until clip.itemCount) {
                    if (photos.size < 15) {
                        val uri = clip.getItemAt(i).uri
                        runCatching { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                        photos.add(uri)
                    }
                }
            } ?: result.data?.data?.let {
                if (photos.size < 15) {
                    runCatching { contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                    photos.add(it)
                }
            }
            refreshSelectedPhotos()
        }
    }


    private val pickMusic = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            result.data?.data?.let { uri ->
                runCatching { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                musicUri = uri
                musicStatus?.text = "Background music selected. Use licensed AAC/M4A audio."
            }
        }
    }
    private var musicStatus: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(20,34,29)
        window.navigationBarColor = android.graphics.Color.rgb(20,34,29)
        buildScreen()
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val result = tts?.setLanguage(Locale("si", "LK"))
                ttsReady = result != TextToSpeech.LANG_MISSING_DATA &&
                    result != TextToSpeech.LANG_NOT_SUPPORTED
            }
        }
    }

    private fun buildScreen() {
        val scroll = ScrollView(this)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 36, 40, 48)
            setBackgroundColor(android.graphics.Color.rgb(247,245,239))
        }
        scroll.addView(col)
        setContentView(scroll)

        val brand = TextView(this).apply {
            text = "DREAMX HOMES\nPROPERTY REEL MAKER"
            textSize = 25f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.rgb(181,139,69))
            setPadding(0, 8, 0, 24)
            typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD)
        }
        col.addView(brand)
        addLabel(col, "Create a luxury property reel")
        val pick = Button(this).apply { text = "SELECT PROPERTY PHOTOS" }
        col.addView(pick, match())
        photoCount = addLabel(col, "No photos selected")
        photoStrip = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 4, 0, 8)
        }
        val photoScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = true
            addView(photoStrip)
        }
        col.addView(photoScroll, match())
        pick.setOnClickListener {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                type = "image/*"; putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                addCategory(Intent.CATEGORY_OPENABLE)
            }
            pickPhotos.launch(intent)
        }

        location = addField(col, "Property location", "e.g. Nugegoda")
        price = addField(col, "Price", "e.g. Rs. 75 Million")
        phone = addField(col, "Contact number", "e.g. 075 087 6292")
        beds = addField(col, "Bedrooms", "e.g. 5")
        baths = addField(col, "Bathrooms", "e.g. 5")
        features = addField(col, "Main features", "Modern pantry, rooftop, parking")

        val makeScript = Button(this).apply { text = "GENERATE SINHALA SCRIPT" }
        col.addView(makeScript, match())
        script = EditText(this).apply {
            hint = "Generated Sinhala narration will appear here. You can edit it."
            minLines = 5; gravity = Gravity.TOP
            setTextSize(16f)
        }
        col.addView(script, match())
        makeScript.setOnClickListener { script.setText(createSinhalaScript()) }

        val speak = Button(this).apply { text = "PREVIEW SINHALA VOICE" }
        col.addView(speak, match())
        speak.setOnClickListener {
            val text = script.text.toString().trim()
            if (text.isEmpty()) {
                toast("Please generate or enter a Sinhala script first.")
            } else if (!ttsReady) {
                toast("Sinhala voice is not available on this phone. Install Sinhala TTS voice data or connect a cloud voice service.")
            } else {
                tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "dreamx_preview")
            }
        }

        val previewReel = Button(this).apply { text = "PREVIEW REEL" }
        col.addView(previewReel, match())
        previewReel.setOnClickListener { showReelPreview() }

        val generateReel = Button(this).apply { text = "GENERATE REEL" }
        col.addView(generateReel, match())
        generateReel.setOnClickListener { startVideoExport(generateReel) }

        val musicButton = Button(this).apply { text = "SELECT BACKGROUND MUSIC (AAC / M4A)" }
        col.addView(musicButton, match())
        musicStatus = addLabel(col, "No background music selected")
        musicButton.setOnClickListener {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                type = "audio/*"
                addCategory(Intent.CATEGORY_OPENABLE)
            }
            pickMusic.launch(intent)
        }

        addLabel(col, "Brand name: DreamX Homes  ·  Watermark + property details + end card")
        addLabel(col, "Video style: Vertical 9:16 · cinematic slow zoom · smooth fades")
        addLabel(col, "Output: MP4 video saved to Gallery and ready to share")
        addLabel(col, "Audio: Sinhala narration from the installed phone TTS is embedded when a script is present. A Sinhala male voice is preferred if the phone provides one; voice gender and quality depend on installed TTS data. Background music is used when no narration script is entered.")
    }

    private fun showReelPreview() {
        if (photos.isEmpty()) {
            toast("Please select property photos first.")
            return
        }

        val dark = android.graphics.Color.rgb(20, 34, 29)
        val gold = android.graphics.Color.rgb(215, 181, 109)
        var index = 0
        var dialog: android.app.AlertDialog? = null

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(18, 18, 18, 18)
            setBackgroundColor(dark)
        }
        val title = TextView(this).apply {
            text = "DREAMX HOMES"
            textSize = 20f
            gravity = Gravity.CENTER
            setTextColor(gold)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(0, 8, 0, 14)
        }
        root.addView(title, match())

        val frame = FrameLayout(this).apply {
            setBackgroundColor(android.graphics.Color.BLACK)
        }
        val photo = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
        }
        frame.addView(photo, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        ))
        root.addView(frame, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        val detailsPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(14, 12, 14, 10)
        }
        val propertyLocation = TextView(this).apply {
            text = location.text.toString().trim().uppercase().ifBlank { "PROPERTY FOR SALE" }
            textSize = 20f
            gravity = Gravity.CENTER
            setTextColor(gold)
            typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD)
            setPadding(4, 4, 4, 6)
        }
        val propertyPrice = TextView(this).apply {
            text = price.text.toString().trim().ifBlank { "PRICE ON REQUEST" }
            textSize = 25f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.WHITE)
            typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD)
            setPadding(4, 2, 4, 8)
        }
        val propertySpecs = TextView(this).apply {
            text = "${beds.text} BEDROOMS   •   ${baths.text} BATHROOMS"
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(gold)
            setPadding(4, 2, 4, 6)
        }
        val propertyFeatures = TextView(this).apply {
            text = features.text.toString().trim()
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.WHITE)
            setPadding(8, 4, 8, 6)
        }
        val contactLine = TextView(this).apply {
            text = "CALL / WHATSAPP  ${phone.text}".trim()
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(gold)
            typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD)
            setPadding(4, 4, 4, 5)
        }
        val brandLine = TextView(this).apply {
            text = "DREAMX HOMES"
            textSize = 13f
            gravity = Gravity.CENTER
            setTextColor(gold)
            letterSpacing = 0.16f
            typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD)
            setPadding(4, 4, 4, 4)
        }
        detailsPanel.addView(propertyLocation, match())
        detailsPanel.addView(propertyPrice, match())
        detailsPanel.addView(propertySpecs, match())
        detailsPanel.addView(propertyFeatures, match())
        detailsPanel.addView(contactLine, match())
        detailsPanel.addView(brandLine, match())
        root.addView(detailsPanel, match())

        val counter = TextView(this).apply {
            gravity = Gravity.CENTER
            textSize = 13f
            setTextColor(gold)
            setPadding(0, 4, 0, 8)
        }
        root.addView(counter, match())

        var isPlaying = false
        val playPause = Button(this).apply { text = "PLAY PREVIEW" }

        fun render() {
            counter.text = "PHOTO ${index + 1} OF ${photos.size}  ·  FULL HD REEL PREVIEW"
            try {
                contentResolver.openInputStream(photos[index])?.use { stream ->
                    val bitmap = android.graphics.BitmapFactory.decodeStream(stream)
                    photo.setImageBitmap(bitmap)
                }
            } catch (_: Exception) {
                photo.setImageDrawable(null)
                toast("Could not open selected photo.")
            }
        }
        val advance = object : Runnable {
            override fun run() {
                if (!isPlaying || dialog?.isShowing != true) return
                index = (index + 1) % photos.size
                render()
                previewHandler.postDelayed(this, 2200L)
            }
        }
        playPause.setOnClickListener {
            isPlaying = !isPlaying
            playPause.text = if (isPlaying) "PAUSE PREVIEW" else "PLAY PREVIEW"
            previewHandler.removeCallbacks(advance)
            if (isPlaying) previewHandler.post(advance)
        }
        root.addView(playPause, match())

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        val previous = Button(this).apply { text = "PREVIOUS" }
        val next = Button(this).apply { text = "NEXT" }
        controls.addView(previous)
        controls.addView(next)
        root.addView(controls, match())
        previous.setOnClickListener {
            index = if (index == 0) photos.lastIndex else index - 1
            render()
        }
        next.setOnClickListener {
            index = (index + 1) % photos.size
            render()
        }

        dialog = android.app.AlertDialog.Builder(this)
            .setView(root)
            .setPositiveButton("CLOSE", null)
            .create()
        dialog?.window?.setBackgroundDrawableResource(android.R.color.transparent)
        render()
        dialog?.show()
        dialog?.window?.setLayout(
            (resources.displayMetrics.widthPixels * 0.94).toInt(),
            (resources.displayMetrics.heightPixels * 0.88).toInt()
        )
        dialog?.setOnDismissListener {
            isPlaying = false
            previewHandler.removeCallbacks(advance)
        }
    }



    private fun refreshSelectedPhotos() {
        photoCount.text = "${photos.size} / 15 photos selected"
        photoStrip.removeAllViews()
        photos.toList().forEachIndexed { index, uri ->
            val tile = FrameLayout(this).apply {
                setBackgroundColor(android.graphics.Color.rgb(20, 34, 29))
            }
            val thumb = ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                val side = (resources.displayMetrics.density * 92).toInt()
                layoutParams = FrameLayout.LayoutParams(side, side)
                runCatching {
                    contentResolver.openInputStream(uri)?.use { input ->
                        setImageBitmap(android.graphics.BitmapFactory.decodeStream(input))
                    }
                }
            }
            tile.addView(thumb)
            val remove = TextView(this).apply {
                text = "×"
                textSize = 20f
                gravity = Gravity.CENTER
                setTextColor(android.graphics.Color.WHITE)
                setBackgroundColor(android.graphics.Color.rgb(190, 35, 45))
                val size = (resources.displayMetrics.density * 28).toInt()
                layoutParams = FrameLayout.LayoutParams(size, size, Gravity.TOP or Gravity.END)
                setOnClickListener {
                    photos.removeAt(index)
                    refreshSelectedPhotos()
                }
            }
            tile.addView(remove)
            val params = LinearLayout.LayoutParams(
                (resources.displayMetrics.density * 92).toInt(),
                (resources.displayMetrics.density * 92).toInt()
            ).apply { marginEnd = (resources.displayMetrics.density * 8).toInt() }
            photoStrip.addView(tile, params)
        }
    }

    private fun startVideoExport(button: Button) {
        if (photos.isEmpty()) {
            toast("Please select property photos first.")
            return
        }
        if (location.text.isNullOrBlank() && price.text.isNullOrBlank()) {
            toast("Please enter at least the property location or price.")
            return
        }
        val photoUris = photos.toList()
        val details = ReelVideoExporter.Details(
            location = location.text.toString().trim(),
            price = price.text.toString().trim(),
            bedrooms = beds.text.toString().trim(),
            bathrooms = baths.text.toString().trim(),
            features = features.text.toString().trim(),
            phone = phone.text.toString().trim(),
            narration = script.text.toString().trim()
        )
        button.isEnabled = false
        button.text = "GENERATING REEL..."
        val progressText = TextView(this).apply {
            textSize = 15f
            setPadding(24, 12, 24, 8)
            text = "Preparing your reel..."
        }
        val progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            isIndeterminate = false
            max = 100
            progress = 0
            setPadding(24, 8, 24, 8)
        }
        val progressLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 8, 12, 12)
            addView(progressText, match())
            addView(progressBar, match())
        }
        val estimatedSeconds = (photoUris.size * 2.0 + 3.0 +
            details.narration.trim().split(Regex("\\s+")).size / 3.5 + 8.0).toInt().coerceAtLeast(10)
        val startedAt = System.currentTimeMillis()
        val dialog = android.app.AlertDialog.Builder(this)
            .setTitle("Creating your property reel")
            .setView(progressLayout)
            .setCancelable(false)
            .create()
        dialog.show()
        progressText.text = "Starting... Estimated time: about $estimatedSeconds seconds"
        var currentPhase = "Preparing"
        val etaTicker = object : Runnable {
            override fun run() {
                if (!dialog.isShowing) return
                val elapsed = ((System.currentTimeMillis() - startedAt) / 1000L).toInt()
                val remaining = (estimatedSeconds - elapsed).coerceAtLeast(0)
                progressText.text = "$currentPhase  ${progressBar.progress}%\\nElapsed: ${elapsed}s  ·  Estimated remaining: ${remaining}s"
                previewHandler.postDelayed(this, 1000L)
            }
        }
        previewHandler.post(etaTicker)

        fun updateProgress(percent: Int, phase: String) {
            currentPhase = phase
            progressBar.progress = percent.coerceIn(0, 100)
            val elapsed = ((System.currentTimeMillis() - startedAt) / 1000L).toInt()
            val remaining = (estimatedSeconds - elapsed).coerceAtLeast(0)
            progressText.text = "$phase  ${progressBar.progress}%\\nElapsed: ${elapsed}s  ·  Estimated remaining: ${remaining}s"
        }

        exportExecutor.execute {
            try {
                val exporter = ReelVideoExporter(this)
                val silentMp4 = exporter.export(photoUris, details) { percent ->
                    runOnUiThread { updateProgress((percent * 0.88).toInt(), "Rendering video") }
                }
                val narrationText = details.narration.trim()
                val finalMp4 = if (narrationText.isNotBlank()) {
                    runOnUiThread { updateProgress(89, "Creating Sinhala voice narration (this stage may take a little longer)") }
                    val narration = SinhalaNarrationGenerator(this).generate(narrationText)
                    runOnUiThread { updateProgress(95, "Adding Sinhala narration: ${narration.voiceName}") }
                    // Narration takes priority over optional music so speech remains clear.
                    exporter.addNarration(silentMp4, narration.audioFile).also {
                        narration.audioFile.delete()
                        if (musicUri != null) runOnUiThread {
                            toast("Sinhala narration added. Background music was skipped so the voice stays clear.")
                        }
                    }
                } else if (musicUri != null) {
                    runOnUiThread { updateProgress(95, "Adding background music") }
                    exporter.addMusic(silentMp4, musicUri!!)
                } else silentMp4
                runOnUiThread { updateProgress(98, "Saving MP4 to Gallery") }
                val saved = saveVideoToGallery(finalMp4)
                runOnUiThread { updateProgress(100, "Completed") }
                    previewHandler.removeCallbacks(etaTicker)
                    dialog.dismiss()
                    button.isEnabled = true
                    button.text = "GENERATE REEL"
                    exportedVideo = saved
                    android.app.AlertDialog.Builder(this)
                        .setTitle("Your Reel is ready!")
                        .setMessage("MP4 saved to Gallery in Movies/DreamX Homes. Share it now?")
                        .setNegativeButton("CLOSE", null)
                        .setPositiveButton("SHARE") { _, _ -> shareVideo(saved) }
                        .show()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    previewHandler.removeCallbacks(etaTicker)
                    dialog.dismiss()
                    button.isEnabled = true
                    button.text = "GENERATE REEL"
                    toast("Export failed (${e.javaClass.simpleName}): ${e.message ?: "No error details. Check phone storage and TTS settings."}")
                }
            }
        }
    }

    private fun saveVideoToGallery(source: File): Uri {
        val values = android.content.ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "DreamX_Homes_${System.currentTimeMillis()}.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "${Environment.DIRECTORY_MOVIES}/DreamX Homes")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("Could not create Gallery video entry")
        try {
            contentResolver.openOutputStream(uri)?.use { out ->
                FileInputStream(source).use { input -> input.copyTo(out) }
            } ?: throw IllegalStateException("Could not write video to Gallery")
            values.clear()
            values.put(MediaStore.Video.Media.IS_PENDING, 0)
            contentResolver.update(uri, values, null, null)
            return uri
        } catch (e: Exception) {
            contentResolver.delete(uri, null, null)
            throw e
        }
    }

    private fun shareVideo(uri: Uri) {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "video/mp4"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, "Share DreamX Homes Reel"))
    }

    private fun createSinhalaScript(): String {
        val loc = location.text.toString().ifBlank { "අලංකාර ස්ථානයක" }
        val p = price.text.toString().ifBlank { "මිල විමසන්න" }
        val b = beds.text.toString().ifBlank { "—" }
        val ba = baths.text.toString().ifBlank { "—" }
        val f = features.text.toString().ifBlank { "නවීන පහසුකම් රැසකින් සමන්විතයි" }
        return "$loc පිහිටි අලංකාර නිවසක් දැන් ඔබට මිලදී ගැනීමට අවස්ථාවක්. " +
            "නිදන කාමර $b ක් සහ නාන කාමර $ba කින් සමන්විත මෙම නිවස $f. " +
            "අපේක්ෂිත මිල $p. වැඩි විස්තර සඳහා DreamX Homes අමතන්න."
    }

    private fun addLabel(parent: LinearLayout, value: String): TextView {
        val t = TextView(this).apply {
            text = value; textSize = 16f
            setTextColor(android.graphics.Color.rgb(35,45,39))
            setPadding(0, 18, 0, 10)
        }
        parent.addView(t, match())
        return t
    }

    private fun addField(parent: LinearLayout, label: String, hintText: String): EditText {
        addLabel(parent, label)
        return EditText(this).apply {
            hint = hintText; textSize = 16f
            setSingleLine(true)
            parent.addView(this, match())
        }
    }

    private fun match() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = 10 }

    private fun toast(message: String) =
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    override fun onDestroy() {
        tts?.stop(); tts?.shutdown()
        exportExecutor.shutdown()
        super.onDestroy()
    }
}
