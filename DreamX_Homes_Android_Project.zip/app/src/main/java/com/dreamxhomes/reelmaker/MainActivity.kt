package com.dreamxhomes.reelmaker

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import java.util.Locale

class MainActivity : ComponentActivity() {
    private val photos = mutableListOf<Uri>()
    private lateinit var photoCount: TextView
    private lateinit var location: EditText
    private lateinit var price: EditText
    private lateinit var phone: EditText
    private lateinit var beds: EditText
    private lateinit var baths: EditText
    private lateinit var features: EditText
    private lateinit var script: EditText
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    private val pickPhotos = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            result.data?.clipData?.let { clip ->
                for (i in 0 until clip.itemCount) {
                    if (photos.size < 15) {
                        val uri = clip.getItemAt(i).uri
                        runCatching { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                        photos.add(uri)
                    }
                }
            } ?: result.data?.data?.let {
                if (photos.size < 15) {
                    runCatching { contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                    photos.add(it)
                }
            }
            photoCount.text = "${photos.size} photos selected (maximum 15)"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(20,34,29)
        window.navigationBarColor = android.graphics.Color.rgb(20,34,29)
        buildScreen()
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val result = tts?.setLanguage(Locale("si", "LK"))
                ttsReady = result != TextToSpeech.LANG_MISSING_DATA &&
                    result != TextToSpeech.LANG_NOT_SUPPORTED
            }
        }
    }

    private fun buildScreen() {
        val scroll = ScrollView(this)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 36, 40, 48)
            setBackgroundColor(android.graphics.Color.rgb(247,245,239))
        }
        scroll.addView(col)
        setContentView(scroll)

        val brand = TextView(this).apply {
            text = "DREAMX HOMES\nPROPERTY REEL MAKER"
            textSize = 25f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.rgb(181,139,69))
            setPadding(0, 8, 0, 24)
            typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD)
        }
        col.addView(brand)
        addLabel(col, "Create a luxury property reel")
        val pick = Button(this).apply { text = "SELECT PROPERTY PHOTOS" }
        col.addView(pick, match())
        photoCount = addLabel(col, "No photos selected")
        pick.setOnClickListener {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                type = "image/*"; putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                addCategory(Intent.CATEGORY_OPENABLE)
            }
            pickPhotos.launch(intent)
        }

        location = addField(col, "Property location", "e.g. Nugegoda")
        price = addField(col, "Price", "e.g. Rs. 75 Million")
        phone = addField(col, "Contact number", "e.g. 075 087 6292")
        beds = addField(col, "Bedrooms", "e.g. 5")
        baths = addField(col, "Bathrooms", "e.g. 5")
        features = addField(col, "Main features", "Modern pantry, rooftop, parking")

        val makeScript = Button(this).apply { text = "GENERATE SINHALA SCRIPT" }
        col.addView(makeScript, match())
        script = EditText(this).apply {
            hint = "Generated Sinhala narration will appear here. You can edit it."
            minLines = 5; gravity = Gravity.TOP
            setTextSize(16f)
        }
        col.addView(script, match())
        makeScript.setOnClickListener { script.setText(createSinhalaScript()) }

        val speak = Button(this).apply { text = "PREVIEW SINHALA VOICE" }
        col.addView(speak, match())
        speak.setOnClickListener {
            val text = script.text.toString().trim()
            if (text.isEmpty()) {
                toast("Please generate or enter a Sinhala script first.")
            } else if (!ttsReady) {
                toast("Sinhala voice is not available on this phone. Install Sinhala TTS voice data or connect a cloud voice service.")
            } else {
                tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "dreamx_preview")
            }
        }

        val previewReel = Button(this).apply { text = "PREVIEW REEL" }
        col.addView(previewReel, match())
        previewReel.setOnClickListener { showReelPreview() }

        val generateReel = Button(this).apply { text = "GENERATE REEL" }
        col.addView(generateReel, match())
        generateReel.setOnClickListener {
            if (photos.isEmpty()) {
                toast("Please select property photos first.")
            } else {
                toast("Your preview is ready. MP4 video export is not implemented in this version yet.")
            }
        }

        addLabel(col, "Branding: DreamX Homes watermark")
        addLabel(col, "Video style: Luxury cinematic · 9:16 Reel")
        addLabel(col, "Music: Soft luxury (add licensed music before export)")
        addLabel(col, "Preview: Photo-by-photo reel preview is available. MP4 export is not yet implemented.")
    }

    private fun showReelPreview() {
        if (photos.isEmpty()) {
            toast("Please select property photos first.")
            return
        }

        val dark = android.graphics.Color.rgb(20, 34, 29)
        val gold = android.graphics.Color.rgb(215, 181, 109)
        var index = 0
        var dialog: android.app.AlertDialog? = null

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(18, 18, 18, 18)
            setBackgroundColor(dark)
        }
        val title = TextView(this).apply {
            text = "DREAMX HOMES"
            textSize = 20f
            gravity = Gravity.CENTER
            setTextColor(gold)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(0, 8, 0, 14)
        }
        root.addView(title, match())

        val frame = FrameLayout(this).apply {
            setBackgroundColor(android.graphics.Color.BLACK)
        }
        val photo = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
        }
        frame.addView(photo, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        ))
        root.addView(frame, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        val details = TextView(this).apply {
            gravity = Gravity.CENTER
            textSize = 17f
            setTextColor(android.graphics.Color.WHITE)
            setPadding(8, 14, 8, 14)
            text = listOf(
                location.text.toString().trim(),
                price.text.toString().trim(),
                "${beds.text} Bedrooms  ·  ${baths.text} Bathrooms",
                phone.text.toString().trim(),
                "DREAMX HOMES"
            ).filter { it.isNotBlank() && it != " Bedrooms  ·   Bathrooms" }
                .joinToString("\\n")
        }
        root.addView(details, match())

        val counter = TextView(this).apply {
            gravity = Gravity.CENTER
            textSize = 13f
            setTextColor(gold)
            setPadding(0, 4, 0, 8)
        }
        root.addView(counter, match())

        fun render() {
            counter.text = "PHOTO ${index + 1} OF ${photos.size}  ·  VERTICAL REEL PREVIEW"
            try {
                contentResolver.openInputStream(photos[index])?.use { stream ->
                    val bitmap = android.graphics.BitmapFactory.decodeStream(stream)
                    photo.setImageBitmap(bitmap)
                }
            } catch (_: Exception) {
                photo.setImageDrawable(null)
                toast("Could not open selected photo.")
            }
        }

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        val previous = Button(this).apply { text = "PREVIOUS" }
        val next = Button(this).apply { text = "NEXT" }
        controls.addView(previous)
        controls.addView(next)
        root.addView(controls, match())
        previous.setOnClickListener {
            index = if (index == 0) photos.lastIndex else index - 1
            render()
        }
        next.setOnClickListener {
            index = (index + 1) % photos.size
            render()
        }

        dialog = android.app.AlertDialog.Builder(this)
            .setView(root)
            .setPositiveButton("CLOSE", null)
            .create()
        dialog?.window?.setBackgroundDrawableResource(android.R.color.transparent)
        render()
        dialog?.show()
        dialog?.window?.setLayout(
            (resources.displayMetrics.widthPixels * 0.94).toInt(),
            (resources.displayMetrics.heightPixels * 0.88).toInt()
        )
    }

    private fun createSinhalaScript(): String {
        val loc = location.text.toString().ifBlank { "අලංකාර ස්ථානයක" }
        val p = price.text.toString().ifBlank { "මිල විමසන්න" }
        val b = beds.text.toString().ifBlank { "—" }
        val ba = baths.text.toString().ifBlank { "—" }
        val f = features.text.toString().ifBlank { "නවීන පහසුකම් රැසකින් සමන්විතයි" }
        return "$loc පිහිටි අලංකාර නිවසක් දැන් ඔබට මිලදී ගැනීමට අවස්ථාවක්. " +
            "නිදන කාමර $b ක් සහ නාන කාමර $ba කින් සමන්විත මෙම නිවස $f. " +
            "අපේක්ෂිත මිල $p. වැඩි විස්තර සඳහා DreamX Homes අමතන්න."
    }

    private fun addLabel(parent: LinearLayout, value: String): TextView {
        val t = TextView(this).apply {
            text = value; textSize = 16f
            setTextColor(android.graphics.Color.rgb(35,45,39))
            setPadding(0, 18, 0, 10)
        }
        parent.addView(t, match())
        return t
    }

    private fun addField(parent: LinearLayout, label: String, hintText: String): EditText {
        addLabel(parent, label)
        return EditText(this).apply {
            hint = hintText; textSize = 16f
            setSingleLine(true)
            parent.addView(this, match())
        }
    }

    private fun match() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = 10 }

    private fun toast(message: String) =
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    override fun onDestroy() {
        tts?.stop(); tts?.shutdown()
        super.onDestroy()
    }
}
