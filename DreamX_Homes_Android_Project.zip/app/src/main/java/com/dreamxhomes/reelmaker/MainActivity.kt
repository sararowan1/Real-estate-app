package com.dreamxhomes.reelmaker

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.media.MediaPlayer
import android.media.MediaMetadataRetriever
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.provider.MediaStore
import android.os.Handler
import android.os.Looper
import android.os.Environment
import java.io.File
import java.io.FileInputStream
import java.io.OutputStream
import java.util.concurrent.Executors
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import java.util.Locale

class MainActivity : ComponentActivity() {
    private val photos = mutableListOf<Uri>()
    private lateinit var photoCount: TextView
    private lateinit var photoStrip: LinearLayout
    private lateinit var location: EditText
    private lateinit var price: EditText
    private lateinit var phone: EditText
    private lateinit var beds: EditText
    private lateinit var baths: EditText
    private lateinit var features: EditText
    private lateinit var script: EditText
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val exportExecutor = Executors.newSingleThreadExecutor()
    private var exportedVideo: Uri? = null
    private var musicUri: Uri? = null
    private var narrationVolume: Float = 1.0f
    private var musicVolume: Float = 0.12f
    private val secureKeyStore by lazy { SecureApiKeyStore(this) }
    private var previewPlayer: MediaPlayer? = null
    private val previewExecutor = Executors.newSingleThreadExecutor()
    private val previewHandler = Handler(Looper.getMainLooper())

    private val pickPhotos = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            val selected = mutableListOf<Uri>()
            result.data?.clipData?.let { clip ->
                for (i in 0 until clip.itemCount) {
                    if (photos.size + selected.size >= 15) break
                    selected.add(clip.getItemAt(i).uri)
                }
            } ?: result.data?.data?.let { selected.add(it) }

            if (selected.isNotEmpty()) {
                toast("Importing ${selected.size} photo(s)...")
                photoImportExecutor.execute {
                    val imported = mutableListOf<Uri>()
                    val failures = mutableListOf<String>()
                    selected.forEachIndexed { index, source ->
                        try {
                            imported.add(copyPhotoIntoAppStorage(source))
                        } catch (e: Exception) {
                            failures.add("Photo ${index + 1}: ${e.message ?: "could not be imported"}")
                        }
                    }
                    runOnUiThread {
                        photos.addAll(imported.take((15 - photos.size).coerceAtLeast(0)))
                        refreshSelectedPhotos()
                        if (failures.isNotEmpty()) {
                            toast("${imported.size} photo(s) imported. ${failures.size} could not be read.")
                        } else {
                            toast("${imported.size} photo(s) ready for preview and export.")
                        }
                    }
                }
            }
        }
    }

    private val photoImportExecutor = Executors.newSingleThreadExecutor()

    /**
     * Copy picker content into app-private storage while the temporary picker grant is valid.
     * Preview and export then read a stable local file URI instead of an expiring provider URI.
     */
    private fun copyPhotoIntoAppStorage(source: Uri): Uri {
        val folder = File(filesDir, "selected_photos").apply { mkdirs() }
        val destination = File(folder, "photo_${System.currentTimeMillis()}_${(0..999999).random()}.img")
        val input = contentResolver.openInputStream(source)
            ?: throw IllegalStateException("Android could not open the selected image.")
        input.use { stream ->
            destination.outputStream().use { output -> stream.copyTo(output) }
        }
        val bounds = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
        android.graphics.BitmapFactory.decodeFile(destination.absolutePath, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
            destination.delete()
            throw IllegalArgumentException("The selected file is not a readable image.")
        }
        return Uri.fromFile(destination)
    }


    private val pickMusic = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            result.data?.data?.let { sourceUri ->
                toast("Adding soundtrack...")
                photoImportExecutor.execute {
                    try {
                        val importedMusic = copyMusicIntoAppStorage(sourceUri)
                        runOnUiThread {
                            musicUri = importedMusic
                            musicTrackName = "Custom soundtrack"
                            refreshMusicTrack()
                            toast("Soundtrack added. It will play in Preview and the exported reel.")
                        }
                    } catch (e: Exception) {
                        runOnUiThread {
                            toast("Could not add soundtrack: ${e.message ?: "file access failed"}")
                        }
                    }
                }
            }
        }
    }
    private var musicStatus: TextView? = null
    private lateinit var musicStrip: LinearLayout
    private var musicTrackName: String = "Luxury sample soundtrack"

    private fun copyMusicIntoAppStorage(source: Uri): Uri {
        val folder = File(filesDir, "selected_music").apply { mkdirs() }
        val destination = File(folder, "soundtrack_${System.currentTimeMillis()}.audio")
        val input = contentResolver.openInputStream(source)
            ?: throw IllegalStateException("Android could not open the selected audio file.")
        input.use { stream ->
            destination.outputStream().use { output -> stream.copyTo(output) }
        }
        if (destination.length() <= 0L) {
            destination.delete()
            throw IllegalArgumentException("The selected audio file is empty.")
        }
        return Uri.fromFile(destination)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(20,34,29)
        window.navigationBarColor = android.graphics.Color.rgb(20,34,29)
        // Load the supplied luxury sample track as the default selectable background music.
        runCatching {
            val sample = File(cacheDir, "dreamx_luxury_sample.mp3")
            if (!sample.exists()) assets.open("danyvin-this-is-luxury-real-estate-634726.mp3").use { input ->
                sample.outputStream().use { output -> input.copyTo(output) }
            }
            musicUri = Uri.fromFile(sample)
            musicTrackName = "Luxury sample soundtrack"
        }
        buildScreen()
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val result = tts?.setLanguage(Locale("si", "LK"))
                ttsReady = result != TextToSpeech.LANG_MISSING_DATA &&
                    result != TextToSpeech.LANG_NOT_SUPPORTED
            }
        }
    }

    private fun buildScreen() {
        val scroll = ScrollView(this)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 36, 40, 48)
            setBackgroundColor(android.graphics.Color.rgb(247,245,239))
        }
        scroll.addView(col)
        setContentView(scroll)

        val brand = TextView(this).apply {
            text = "DREAMX HOMES\nPROPERTY REEL MAKER"
            textSize = 25f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.rgb(181,139,69))
            setPadding(0, 8, 0, 24)
            typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD)
        }
        col.addView(brand)
        addLabel(col, "Create a luxury property reel")
        val pick = Button(this).apply { text = "SELECT PROPERTY PHOTOS" }
        col.addView(pick, match())
        photoCount = addLabel(col, "No photos selected")
        photoStrip = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 4, 0, 8)
        }
        val photoScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = true
            addView(photoStrip)
        }
        col.addView(photoScroll, match())
        pick.setOnClickListener {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                type = "image/*"; putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                addCategory(Intent.CATEGORY_OPENABLE)
            }
            pickPhotos.launch(intent)
        }

        location = addField(col, "Property location", "e.g. Nugegoda")
        price = addField(col, "Price", "e.g. Rs. 75 Million")
        phone = addField(col, "Contact number", "e.g. 075 087 6292")
        beds = addField(col, "Bedrooms", "e.g. 5")
        baths = addField(col, "Bathrooms", "e.g. 5")
        features = addField(col, "Main features", "Modern pantry, rooftop, parking")

        val makeScript = Button(this).apply { text = "GENERATE SINHALA SCRIPT" }
        col.addView(makeScript, match())
        script = EditText(this).apply {
            hint = "Generated Sinhala narration will appear here. You can edit it."
            minLines = 5; gravity = Gravity.TOP
            setTextSize(16f)
        }
        col.addView(script, match())
        makeScript.setOnClickListener { script.setText(createSinhalaScript()) }

        val voiceSettings = Button(this).apply { text = "SET UP FREE CHARON AI VOICE" }
        col.addView(voiceSettings, match())
        voiceSettings.setOnClickListener { showGeminiKeyDialog() }

        val speak = Button(this).apply { text = "PREVIEW SINHALA VOICE" }
        col.addView(speak, match())
        speak.setOnClickListener {
            val text = script.text.toString().trim()
            if (text.isEmpty()) {
                toast("Please generate or enter a Sinhala script first.")
            } else {
                val key = secureKeyStore.read()
                if (!key.isNullOrBlank()) {
                    speak.isEnabled = false
                    speak.text = "GENERATING CHARON PREVIEW..."
                    previewExecutor.execute {
                        try {
                            val wav = File(cacheDir, "dreamx_charon_preview.wav")
                            GeminiCharonTts().synthesizeToWav(key, text, wav)
                            runOnUiThread {
                                previewPlayer?.release()
                                previewPlayer = MediaPlayer().apply {
                                    setDataSource(wav.absolutePath)
                                    setOnPreparedListener { it.start(); speak.isEnabled = true; speak.text = "PREVIEW SINHALA VOICE" }
                                    setOnCompletionListener { it.release(); previewPlayer = null; wav.delete() }
                                    setOnErrorListener { player, _, _ -> player.release(); previewPlayer = null; speak.isEnabled = true; speak.text = "PREVIEW SINHALA VOICE"; toast("Could not play voice preview."); true }
                                    prepareAsync()
                                }
                            }
                        } catch (e: Exception) {
                            runOnUiThread {
                                speak.isEnabled = true; speak.text = "PREVIEW SINHALA VOICE"
                                toast("Charon preview failed: ${e.message}. Using phone voice instead.")
                                if (ttsReady) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "dreamx_preview")
                            }
                        }
                    }
                } else if (ttsReady) {
                    tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "dreamx_preview")
                } else toast("Set up Charon in Voice Settings or install a Sinhala phone voice.")
            }
        }

        val previewReel = Button(this).apply { text = "PREVIEW REEL" }
        col.addView(previewReel, match())
        previewReel.setOnClickListener { showReelPreview() }

        val generateReel = Button(this).apply { text = "GENERATE REEL" }
        col.addView(generateReel, match())
        generateReel.setOnClickListener { startVideoExport(generateReel) }

        addLabel(col, "BACKGROUND SOUNDTRACK")
        musicStrip = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 4, 0, 8)
        }
        col.addView(musicStrip, match())
        val musicButton = Button(this).apply { text = "＋ ADD / CHANGE MUSIC TRACK" }
        col.addView(musicButton, match())
        musicStatus = addLabel(col, "")
        refreshMusicTrack()
        musicButton.setOnClickListener {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                type = "audio/*"
                addCategory(Intent.CATEGORY_OPENABLE)
            }
            pickMusic.launch(intent)
        }

        addLabel(col, "AUDIO MIXER — ADJUST BEFORE PREVIEW")
        val voiceValue = addLabel(col, "Narrator volume: 100%")
        val voiceSlider = SeekBar(this).apply {
            max = 100
            progress = (narrationVolume * 100).toInt()
        }
        voiceSlider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                narrationVolume = progress / 100f
                voiceValue.text = "Narrator volume: $progress%"
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        col.addView(voiceSlider, match())
        val musicValue = addLabel(col, "Background music volume: 12%")
        val musicSlider = SeekBar(this).apply {
            max = 100
            progress = (musicVolume * 100).toInt()
        }
        musicSlider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                musicVolume = progress / 100f
                musicValue.text = "Background music volume: $progress%"
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        col.addView(musicSlider, match())

        addLabel(col, "Brand name: DreamX Homes  ·  Watermark + property details + end card")
        addLabel(col, "Video style: Vertical 9:16 · cinematic slow zoom · smooth fades")
        addLabel(col, "Output: MP4 video saved to Gallery and ready to share")
        addLabel(col, "Audio Studio: synchronized narrator + background music with adjustable separate volume controls. Music starts with the narrator and loops/trims to the full video duration. Choose licensed music or your own audio.")
    }

    private fun showReelPreview() {
        if (photos.isEmpty()) {
            toast("Please select property photos first.")
            return
        }

        val photoUris = photos.toList()
        val narrationText = script.text.toString().trim()
        val savedKey = secureKeyStore.read()
        val dark = android.graphics.Color.rgb(20, 34, 29)
        val gold = android.graphics.Color.rgb(215, 181, 109)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 12, 12, 12)
            setBackgroundColor(dark)
        }
        val title = TextView(this).apply {
            text = "DREAMX HOMES — QUICK PREVIEW"
            textSize = 17f
            gravity = Gravity.CENTER
            setTextColor(gold)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(0, 4, 0, 10)
        }
        root.addView(title, match())

        val image = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(android.graphics.Color.BLACK)
            contentDescription = "Property photo preview"
        }
        root.addView(image, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        val counter = TextView(this).apply {
            text = "Loading first photo..."
            textSize = 13f
            gravity = Gravity.CENTER
            setTextColor(gold)
            setPadding(4, 6, 4, 4)
        }
        root.addView(counter, match())

        val narratorLabel = TextView(this).apply {
            text = if (narrationText.isBlank()) "No narration script entered."
                   else "CHARON AI NARRATOR\n$narrationText"
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.WHITE)
            setPadding(8, 8, 8, 8)
        }
        root.addView(narratorLabel, match())

        val status = TextView(this).apply {
            text = "Showing photos immediately. Preparing Charon voice..."
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(gold)
            setPadding(4, 4, 4, 8)
        }
        root.addView(status, match())

        val replay = Button(this).apply { text = "RESTART PHOTO PREVIEW" }
        root.addView(replay, match())

        val dialog = android.app.AlertDialog.Builder(this)
            .setView(root)
            .setNegativeButton("CLOSE", null)
            .create()

        var currentIndex = 0
        var dismissed = false
        var narratorPlayer: MediaPlayer? = null
        var musicPlayer: MediaPlayer? = null
        var slideshowRunnable: Runnable? = null

        fun showPhoto(index: Int) {
            if (dismissed || photoUris.isEmpty()) return
            val safeIndex = index % photoUris.size
            previewExecutor.execute {
                try {
                    val uri = photoUris[safeIndex]
                    val bounds = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    contentResolver.openInputStream(uri)?.use {
                        android.graphics.BitmapFactory.decodeStream(it, null, bounds)
                    } ?: throw IllegalStateException("Cannot open selected photo.")
                    val sample = calculateInSampleSize(bounds, 1280, 720)
                    val options = android.graphics.BitmapFactory.Options().apply {
                        inSampleSize = sample
                        inPreferredConfig = android.graphics.Bitmap.Config.RGB_565
                    }
                    val bitmap = contentResolver.openInputStream(uri)?.use {
                        android.graphics.BitmapFactory.decodeStream(it, null, options)
                    } ?: throw IllegalStateException("Cannot decode selected photo.")
                    runOnUiThread {
                        if (!dismissed && dialog.isShowing) {
                            image.setImageBitmap(bitmap)
                            currentIndex = safeIndex
                            counter.text = "PHOTO ${safeIndex + 1} / ${photoUris.size}"
                        } else bitmap.recycle()
                    }
                } catch (e: Exception) {
                    runOnUiThread {
                        if (!dismissed && dialog.isShowing) {
                            counter.text = "Photo ${safeIndex + 1} could not be displayed: ${e.message}"
                        }
                    }
                }
            }
        }

        fun startSlideshow() {
            slideshowRunnable?.let { previewHandler.removeCallbacks(it) }
            slideshowRunnable = object : Runnable {
                override fun run() {
                    if (dismissed || !dialog.isShowing) return
                    showPhoto((currentIndex + 1) % photoUris.size)
                    previewHandler.postDelayed(this, 3500L)
                }
            }
            previewHandler.postDelayed(slideshowRunnable!!, 3500L)
        }

        dialog.setOnDismissListener {
            dismissed = true
            slideshowRunnable?.let { previewHandler.removeCallbacks(it) }
            runCatching { narratorPlayer?.stop() }
            runCatching { narratorPlayer?.release() }
            narratorPlayer = null
            runCatching { musicPlayer?.stop() }
            runCatching { musicPlayer?.release() }
            musicPlayer = null
            previewPlayer?.release()
            previewPlayer = null
        }
        dialog.show()
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.window?.setLayout(
            (resources.displayMetrics.widthPixels * 0.94).toInt(),
            (resources.displayMetrics.heightPixels * 0.88).toInt()
        )

        replay.setOnClickListener {
            showPhoto(0)
            currentIndex = 0
            narratorPlayer?.let { player ->
                runCatching { player.seekTo(0); player.start() }
            }
            musicPlayer?.let { player ->
                runCatching { player.seekTo(0); player.start() }
            }
        }

        // Start showing the selected property photos immediately; do not render a full MP4 for preview.
        showPhoto(0)
        startSlideshow()

        // Start optional background music independently so photo preview is never blocked by TTS.
        musicUri?.let { selectedMusic ->
            Thread {
                try {
                    val player = MediaPlayer()
                    player.setDataSource(this, selectedMusic)
                    player.isLooping = true
                    player.setVolume(musicVolume, musicVolume)
                    player.setOnPreparedListener {
                        if (!dismissed) it.start() else it.release()
                    }
                    player.setOnErrorListener { mp, _, _ ->
                        mp.release()
                        runOnUiThread { if (!dismissed && dialog.isShowing) status.text = "Background music could not be played." }
                        true
                    }
                    musicPlayer = player
                    player.prepareAsync()
                } catch (e: Exception) {
                    runOnUiThread { if (!dismissed && dialog.isShowing) status.text = "Music preview unavailable: ${e.message}" }
                }
            }.start()
        }

        if (narrationText.isBlank()) {
            status.text = "Photo preview is ready. Add narration text to hear Charon."
        } else if (savedKey.isNullOrBlank()) {
            status.text = "Photos are playing. Add your Gemini API key in Voice Settings to generate Charon narration."
        } else {
            status.text = "Photos are playing. Generating Gemini Charon narration..."
            Thread {
                var wav: File? = null
                try {
                    val scriptCacheId = Integer.toHexString(narrationText.hashCode())
                    wav = File(filesDir, "charon_${scriptCacheId}.wav")
                    if (!wav.exists() || wav.length() < 48L) {
                        GeminiCharonTts().synthesizeToWav(savedKey, narrationText, wav)
                    }
                    val audioFile = wav
                    runOnUiThread {
                        if (dismissed || !dialog.isShowing) {
                            audioFile.delete()
                            return@runOnUiThread
                        }
                        status.text = "CHARON NARRATION READY — playing male AI voice."
                        val player = MediaPlayer()
                        narratorPlayer = player
                        player.setDataSource(audioFile.absolutePath)
                        player.setVolume(narrationVolume, narrationVolume)
                        player.setOnPreparedListener {
                            if (!dismissed) it.start() else it.release()
                        }
                        player.setOnCompletionListener {
                            it.release()
                            narratorPlayer = null
                            if (!dismissed && dialog.isShowing) status.text = "Charon narration finished. Photos continue playing."
                        }
                        player.setOnErrorListener { mp, _, _ ->
                            mp.release()
                            narratorPlayer = null
                            if (!dismissed && dialog.isShowing) status.text = "Charon audio playback failed."
                            true
                        }
                        player.prepareAsync()
                    }
                } catch (e: Exception) {
                    runOnUiThread {
                        if (!dismissed && dialog.isShowing) status.text = "Charon narration unavailable: ${e.message ?: e.javaClass.simpleName}"
                    }
                }
            }.start()
        }
    }

    private fun calculateInSampleSize(
        options: android.graphics.BitmapFactory.Options,
        reqWidth: Int,
        reqHeight: Int
    ): Int {
        val height = options.outHeight
        val width = options.outWidth
        var sample = 1
        if (height > reqHeight || width > reqWidth) {
            var halfHeight = height / 2
            var halfWidth = width / 2
            while ((halfHeight / sample) >= reqHeight && (halfWidth / sample) >= reqWidth) {
                sample *= 2
            }
        }
        return sample.coerceAtLeast(1)
    }

    private fun refreshMusicTrack() {
        if (!::musicStrip.isInitialized) return
        musicStrip.removeAllViews()
        val selected = musicUri
        if (selected == null) {
            val empty = TextView(this).apply {
                text = "No soundtrack selected — preview will be silent."
                textSize = 13f
                setTextColor(android.graphics.Color.DKGRAY)
                setPadding(10, 14, 10, 14)
            }
            musicStrip.addView(empty, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ))
            musicStatus?.text = "Add a music track to hear it in Preview."
            return
        }

        val tile = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(12, 10, 8, 10)
            setBackgroundColor(android.graphics.Color.rgb(20, 34, 29))
        }
        val icon = TextView(this).apply {
            text = "♫"
            textSize = 28f
            setTextColor(android.graphics.Color.rgb(215, 181, 109))
            gravity = Gravity.CENTER
        }
        tile.addView(icon, LinearLayout.LayoutParams(
            (resources.displayMetrics.density * 42).toInt(),
            (resources.displayMetrics.density * 48).toInt()
        ))
        val details = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val name = TextView(this).apply {
            text = musicTrackName
            textSize = 14f
            setTextColor(android.graphics.Color.WHITE)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        val subtitle = TextView(this).apply {
            text = "Selected soundtrack · plays in Preview and Export"
            textSize = 11f
            setTextColor(android.graphics.Color.LTGRAY)
        }
        details.addView(name)
        details.addView(subtitle)
        tile.addView(details, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        val remove = TextView(this).apply {
            text = "×"
            textSize = 25f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.WHITE)
            setBackgroundColor(android.graphics.Color.rgb(190, 35, 45))
            val size = (resources.displayMetrics.density * 36).toInt()
            layoutParams = LinearLayout.LayoutParams(size, size)
            contentDescription = "Remove soundtrack"
            setOnClickListener {
                musicUri = null
                musicTrackName = ""
                refreshMusicTrack()
            }
        }
        tile.addView(remove)
        musicStrip.addView(tile, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ))
        musicStatus?.text = "Soundtrack ready. Preview starts it at 00:00 and loops it."
    }

    private fun refreshSelectedPhotos() {
        photoCount.text = "${photos.size} / 15 photos selected"
        photoStrip.removeAllViews()
        photos.toList().forEachIndexed { index, uri ->
            val tile = FrameLayout(this).apply {
                setBackgroundColor(android.graphics.Color.rgb(20, 34, 29))
            }
            val thumb = ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                val side = (resources.displayMetrics.density * 92).toInt()
                layoutParams = FrameLayout.LayoutParams(side, side)
                runCatching {
                    val path = uri.path
                    if (uri.scheme == "file" && path != null) {
                        val bounds = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
                        android.graphics.BitmapFactory.decodeFile(path, bounds)
                        val opts = android.graphics.BitmapFactory.Options().apply {
                            inSampleSize = calculateInSampleSize(bounds, 240, 240)
                            inPreferredConfig = android.graphics.Bitmap.Config.RGB_565
                        }
                        setImageBitmap(android.graphics.BitmapFactory.decodeFile(path, opts))
                    } else {
                        contentResolver.openInputStream(uri)?.use { input ->
                            setImageBitmap(android.graphics.BitmapFactory.decodeStream(input))
                        }
                    }
                }
            }
            tile.addView(thumb)
            val remove = TextView(this).apply {
                text = "×"
                textSize = 20f
                gravity = Gravity.CENTER
                setTextColor(android.graphics.Color.WHITE)
                setBackgroundColor(android.graphics.Color.rgb(190, 35, 45))
                val size = (resources.displayMetrics.density * 28).toInt()
                layoutParams = FrameLayout.LayoutParams(size, size, Gravity.TOP or Gravity.END)
                setOnClickListener {
                    photos.removeAt(index)
                    refreshSelectedPhotos()
                }
            }
            tile.addView(remove)
            val params = LinearLayout.LayoutParams(
                (resources.displayMetrics.density * 92).toInt(),
                (resources.displayMetrics.density * 92).toInt()
            ).apply { marginEnd = (resources.displayMetrics.density * 8).toInt() }
            photoStrip.addView(tile, params)
        }
    }

    private fun startVideoExport(button: Button) {
        if (photos.isEmpty()) {
            toast("Please select property photos first.")
            return
        }
        if (location.text.isNullOrBlank() && price.text.isNullOrBlank()) {
            toast("Please enter at least the property location or price.")
            return
        }
        val photoUris = photos.toList()
        val details = ReelVideoExporter.Details(
            location = location.text.toString().trim(),
            price = price.text.toString().trim(),
            bedrooms = beds.text.toString().trim(),
            bathrooms = baths.text.toString().trim(),
            features = features.text.toString().trim(),
            phone = phone.text.toString().trim(),
            narration = script.text.toString().trim()
        )
        button.isEnabled = false
        button.text = "GENERATING REEL..."
        val progressText = TextView(this).apply {
            textSize = 15f
            setPadding(24, 12, 24, 8)
            text = "Preparing your reel..."
        }
        val progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            isIndeterminate = false
            max = 100
            progress = 0
            setPadding(24, 8, 24, 8)
        }
        val progressLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 8, 12, 12)
            addView(progressText, match())
            addView(progressBar, match())
        }
        val estimatedSeconds = (photoUris.size * 2.0 + 3.0 +
            details.narration.trim().split(Regex("\\s+")).size / 3.5 + 8.0).toInt().coerceAtLeast(10)
        val startedAt = System.currentTimeMillis()
        val dialog = android.app.AlertDialog.Builder(this)
            .setTitle("Creating your property reel")
            .setView(progressLayout)
            .setCancelable(false)
            .create()
        dialog.show()
        progressText.text = "Starting... Estimated time: about $estimatedSeconds seconds"
        var currentPhase = "Preparing"
        val etaTicker = object : Runnable {
            override fun run() {
                if (!dialog.isShowing) return
                val elapsed = ((System.currentTimeMillis() - startedAt) / 1000L).toInt()
                val remaining = (estimatedSeconds - elapsed).coerceAtLeast(0)
                progressText.text = "$currentPhase  ${progressBar.progress}%\nElapsed: ${elapsed}s  ·  Estimated remaining: ${remaining}s"
                previewHandler.postDelayed(this, 1000L)
            }
        }
        previewHandler.post(etaTicker)

        fun updateProgress(percent: Int, phase: String) {
            currentPhase = phase
            progressBar.progress = percent.coerceIn(0, 100)
            val elapsed = ((System.currentTimeMillis() - startedAt) / 1000L).toInt()
            val remaining = (estimatedSeconds - elapsed).coerceAtLeast(0)
            progressText.text = "$phase  ${progressBar.progress}%\nElapsed: ${elapsed}s  ·  Estimated remaining: ${remaining}s"
        }

        exportExecutor.execute {
            try {
                val exporter = ReelVideoExporter(this)
                val narrationText = details.narration.trim()
                var narrationAudio: File? = null
                if (narrationText.isNotBlank()) {
                    runOnUiThread { updateProgress(4, "Creating Sinhala voice narration") }
                    val savedKey = secureKeyStore.read()
                    narrationAudio = if (!savedKey.isNullOrBlank()) {
                        try {
                            runOnUiThread { updateProgress(8, "Generating Charon Sinhala narration") }
                            val wav = File(cacheDir, "dreamx_charon_${System.currentTimeMillis()}.wav")
                            GeminiCharonTts().synthesizeToWav(savedKey, narrationText, wav)
                            SinhalaNarrationGenerator(this).encodeExternalWavToAac(wav)
                        } catch (cloudError: Exception) {
                            runOnUiThread { toast("Charon unavailable: ${cloudError.message}. Using phone Sinhala voice.") }
                            SinhalaNarrationGenerator(this).generate(narrationText).audioFile
                        }
                    } else SinhalaNarrationGenerator(this).generate(narrationText).audioFile
                }

                // Match the photo sequence to the actual narration duration, then reserve
                // exactly the final 10 seconds for the DreamX Homes closing card.
                val narrationSeconds = narrationAudio?.let { getAudioDurationSeconds(it) }
                val photoDurationSeconds = narrationSeconds?.coerceAtLeast(5)
                    ?: maxOf(10, photoUris.size * 2)

                runOnUiThread { updateProgress(12, "Rendering property photos for ${photoDurationSeconds}s") }
                val silentMp4 = exporter.export(photoUris, details, photoDurationSeconds) { percent ->
                    runOnUiThread { updateProgress(12 + (percent * 0.76).toInt(), "Rendering photo sequence and final 10-second brand card") }
                }

                val selectedMusic = musicUri
                val finalMp4 = if (narrationAudio != null || selectedMusic != null) {
                    runOnUiThread { updateProgress(90, "Mixing narration and background music") }
                    try {
                        AudioMixEngine(this).mixIntoVideo(silentMp4, narrationAudio, selectedMusic,
                            musicVolume = musicVolume, voiceVolume = narrationVolume, duckVolume = minOf(musicVolume, 0.055f)) { percent ->
                            runOnUiThread { updateProgress(90 + (percent * 0.07f).toInt(), "Professional audio mixing") }
                        }
                    } finally { narrationAudio?.delete() }
                } else silentMp4
                runOnUiThread { updateProgress(98, "Saving MP4 to Gallery") }
                val saved = saveVideoToGallery(finalMp4)
                runOnUiThread {
                    updateProgress(100, "Completed")
                    previewHandler.removeCallbacks(etaTicker)
                    dialog.dismiss()
                    button.isEnabled = true
                    button.text = "GENERATE REEL"
                    exportedVideo = saved
                    android.app.AlertDialog.Builder(this@MainActivity)
                        .setTitle("Your Reel is ready!")
                        .setMessage("MP4 saved to Gallery in Movies/DreamX Homes. Share it now?")
                        .setNegativeButton("CLOSE", null)
                        .setNeutralButton("DOWNLOAD") { _, _ ->
                            exportExecutor.execute {
                                try {
                                    val downloaded = copyVideoToDownloads(saved)
                                    runOnUiThread { toast("Downloaded to Downloads/DreamX Homes") }
                                } catch (downloadError: Exception) {
                                    runOnUiThread {
                                        toast("Download failed: ${downloadError.message ?: downloadError.javaClass.simpleName}")
                                    }
                                }
                            }
                        }
                        .setPositiveButton("SHARE") { _, _ -> shareVideo(saved) }
                        .show()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    previewHandler.removeCallbacks(etaTicker)
                    dialog.dismiss()
                    button.isEnabled = true
                    button.text = "GENERATE REEL"
                    toast("Export failed (${e.javaClass.simpleName}): ${e.message ?: "No error details. Check phone storage and TTS settings."}")
                }
            }
        }
    }

    private fun getAudioDurationSeconds(audioFile: File): Int {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(audioFile.absolutePath)
            val durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                ?.toLongOrNull() ?: 0L
            ((durationMs + 999L) / 1000L).toInt().coerceAtLeast(5)
        } finally {
            runCatching { retriever.release() }
        }
    }

    private fun saveVideoToGallery(source: File): Uri {
        val values = android.content.ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "DreamX_Homes_${System.currentTimeMillis()}.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "${Environment.DIRECTORY_MOVIES}/DreamX Homes")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("Could not create Gallery video entry")
        try {
            contentResolver.openOutputStream(uri)?.use { out ->
                FileInputStream(source).use { input -> input.copyTo(out) }
            } ?: throw IllegalStateException("Could not write video to Gallery")
            values.clear()
            values.put(MediaStore.Video.Media.IS_PENDING, 0)
            contentResolver.update(uri, values, null, null)
            return uri
        } catch (e: Exception) {
            contentResolver.delete(uri, null, null)
            throw e
        }
    }

    private fun copyVideoToDownloads(sourceUri: Uri): Uri {
        val values = android.content.ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "DreamX_Homes_${System.currentTimeMillis()}.mp4")
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/DreamX Homes")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val destination = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("Could not create a Downloads entry")
        try {
            val input = contentResolver.openInputStream(sourceUri)
                ?: throw IllegalStateException("Could not read the generated Reel")
            val output = contentResolver.openOutputStream(destination)
                ?: throw IllegalStateException("Could not write the Reel to Downloads")
            input.use { src -> output.use { dst -> src.copyTo(dst) } }
            val ready = android.content.ContentValues().apply {
                put(MediaStore.MediaColumns.IS_PENDING, 0)
            }
            contentResolver.update(destination, ready, null, null)
            return destination
        } catch (e: Exception) {
            contentResolver.delete(destination, null, null)
            throw e
        }
    }

    private fun shareVideo(uri: Uri) {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "video/mp4"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, "Share DreamX Homes Reel"))
    }

    private fun showGeminiKeyDialog() {
        val input = EditText(this).apply {
            hint = "Paste your Google AI Studio API key"
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(secureKeyStore.read().orEmpty())
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 12, 28, 4)
            addView(input, match())
            addView(TextView(this@MainActivity).apply {
                text = "Create a key at aistudio.google.com/api-keys. It is encrypted at rest with Android Keystore. A key stored on a phone is still extractable by a sufficiently capable attacker; for a public commercial release, use a private backend instead. Gemini free-tier use is quota-limited and Google may use free-tier content to improve its products."
                textSize = 12f
            }, match())
        }
        android.app.AlertDialog.Builder(this)
            .setTitle("Charon AI Voice Setup")
            .setView(content)
            .setPositiveButton("SAVE KEY") { _, _ ->
                runCatching { secureKeyStore.save(input.text.toString()) }
                    .onSuccess { toast("Charon voice key saved securely on this phone.") }
                    .onFailure { toast("Could not save API key: ${it.message}") }
            }
            .setNeutralButton("REMOVE KEY") { _, _ -> secureKeyStore.clear(); toast("AI voice key removed.") }
            .setNegativeButton("CANCEL", null)
            .show()
    }

    private fun createSinhalaScript(): String {
        val loc = location.text.toString().ifBlank { "අලංකාර ස්ථානයක" }
        val p = price.text.toString().ifBlank { "මිල විමසන්න" }
        val b = beds.text.toString().ifBlank { "—" }
        val ba = baths.text.toString().ifBlank { "—" }
        val f = features.text.toString().ifBlank { "නවීන පහසුකම් රැසකින් සමන්විතයි" }
        // Write this as spoken Sinhala, not a compressed classified-ad sentence.
        // Short, natural sentences give the TTS engine room for human-like phrasing.
        return "$loc ප්‍රදේශයෙන්, ඔබේ පවුලට ගැළපෙන නිවසක් සොයනවාද? " +
            "එහෙනම් මේ නිවස ගැන ටිකක් දැනගනිමු. " +
            "නිදන කාමර $b ක් සහ නාන කාමර $ba ක් මෙහි තියෙනවා. " +
            "$f. " +
            "මෙහි අපේක්ෂිත මිල $p. " +
            "වැඩි විස්තර දැනගන්න, නැත්නම් නිවස නැරඹීමට වේලාවක් වෙන් කරගන්න, DreamX Homes අමතන්න."
    }

    private fun addLabel(parent: LinearLayout, value: String): TextView {
        val t = TextView(this).apply {
            text = value; textSize = 16f
            setTextColor(android.graphics.Color.rgb(35,45,39))
            setPadding(0, 18, 0, 10)
        }
        parent.addView(t, match())
        return t
    }

    private fun addField(parent: LinearLayout, label: String, hintText: String): EditText {
        addLabel(parent, label)
        return EditText(this).apply {
            hint = hintText; textSize = 16f
            setSingleLine(true)
            parent.addView(this, match())
        }
    }

    private fun match() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = 10 }

    private fun toast(message: String) =
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    override fun onDestroy() {
        tts?.stop(); tts?.shutdown()
        previewPlayer?.release(); previewPlayer = null
        previewExecutor.shutdown()
        exportExecutor.shutdown()
        super.onDestroy()
    }
}
