package com.dreamxhomes.reelmaker

import android.util.Base64
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.DataOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** Gemini 2.5 Flash Preview TTS client configured to use the Charon voice. The API key belongs to the user and is never hard-coded. */
class GeminiCharonTts {
    fun synthesizeToWav(apiKey: String, text: String, output: File): File {
        require(apiKey.isNotBlank()) { "Add your Google AI Studio API key in Voice Settings." }
        require(text.isNotBlank()) { "Enter a Sinhala narration script first." }
        require(text.toByteArray(Charsets.UTF_8).size <= 3500) {
            "Please shorten the narration to fit the TTS request limit."
        }
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-tts:generateContent")
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 8000
            readTimeout = 15000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("x-goog-api-key", apiKey)
        }
        try {
            // Keep the direction short and conversational. Long, over-specified prompts can make
            // TTS sound like an announcer or cause unnatural emphasis. The transcript itself
            // carries the pauses through ordinary Sinhala punctuation.
            val textPrompt = "Speak the following as a real Sri Lankan property consultant talking naturally to a potential buyer. Use a warm, relaxed, confident male-presenter delivery: conversational rather than a formal newsreader or advertisement announcer. Vary intonation gently, keep a human rhythm, pronounce Sinhala clearly, and pause briefly at commas and sentence endings. Do not add words, translate, or read these instructions aloud. Say only this Sinhala script: $text"
            val partsArray = org.json.JSONArray().put(JSONObject().put("text", textPrompt))
            val content = JSONObject().put("parts", partsArray)
            val contents = org.json.JSONArray().put(content)
            val prebuiltVoice = JSONObject().put("voiceName", "Charon")
            val voiceConfig = JSONObject().put("prebuiltVoiceConfig", prebuiltVoice)
            val speechConfig = JSONObject().put("languageCode", "si-LK").put("voiceConfig", voiceConfig)
            val generationConfig = JSONObject()
                .put("responseModalities", org.json.JSONArray().put("AUDIO"))
                .put("speechConfig", speechConfig)
            val body = JSONObject()
                .put("contents", contents)
                .put("generationConfig", generationConfig)
                .toString()
            connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val status = connection.responseCode
            val responseText = (if (status in 200..299) connection.inputStream else connection.errorStream)
                ?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (status == 429) {
                throw IllegalStateException(
                    "Gemini Charon quota exceeded (HTTP 429). Your Google AI Studio free-tier TTS limit is exhausted. " +
                    "Photos preview will continue; Charon voice will work again when quota resets or billing/quota is increased."
                )
            }
            if (status == 403) {
                throw IllegalStateException(
                    "Gemini Charon access denied (HTTP 403). Check that this API key has Gemini TTS access and billing is configured."
                )
            }
            check(status in 200..299) { "Gemini TTS request failed ($status): ${responseText.take(250)}" }
            val root = JSONObject(responseText)
            val parts = root.optJSONArray("candidates")?.optJSONObject(0)
                ?.optJSONObject("content")?.optJSONArray("parts")
                ?: throw IllegalStateException("Gemini returned no audio. Try again or use the phone voice.")
            var pcm: ByteArray? = null
            for (i in 0 until parts.length()) {
                val inline = parts.optJSONObject(i)?.optJSONObject("inlineData")
                if (inline != null && inline.optString("mimeType").startsWith("audio/")) {
                    pcm = Base64.decode(inline.getString("data"), Base64.DEFAULT)
                    break
                }
            }
            val raw = pcm ?: throw IllegalStateException("Gemini returned no audio data. Try again.")
            // Gemini TTS audio response is 24 kHz, 16-bit, mono PCM (no WAV header).
            writeWav(output, raw, 24000, 1, 16)
            return output
        } finally {
            connection.disconnect()
        }
    }

    private fun writeWav(file: File, pcm: ByteArray, sampleRate: Int, channels: Int, bits: Int) {
        val byteRate = sampleRate * channels * bits / 8
        val out = ByteArrayOutputStream(44 + pcm.size)
        val data = DataOutputStream(out)
        fun ascii(s: String) { data.writeBytes(s) }
        fun le16(v: Int) { data.writeByte(v and 255); data.writeByte((v shr 8) and 255) }
        fun le32(v: Int) { data.writeByte(v and 255); data.writeByte((v shr 8) and 255); data.writeByte((v shr 16) and 255); data.writeByte((v shr 24) and 255) }
        ascii("RIFF"); le32(36 + pcm.size); ascii("WAVE"); ascii("fmt "); le32(16)
        le16(1); le16(channels); le32(sampleRate); le32(byteRate); le16(channels * bits / 8); le16(bits)
        ascii("data"); le32(pcm.size); data.write(pcm); data.flush()
        file.writeBytes(out.toByteArray())
    }
}
