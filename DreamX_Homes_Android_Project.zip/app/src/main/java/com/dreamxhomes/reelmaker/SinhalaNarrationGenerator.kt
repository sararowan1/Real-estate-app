package com.dreamxhomes.reelmaker

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.io.File
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference

/**
 * Generates Sinhala narration with the phone's installed TTS engine and encodes it as AAC/M4A.
 * A male voice is selected when the installed engine exposes one; Android does not expose
 * reliable voice-gender metadata, so the selected voice name is returned for transparency.
 */
class SinhalaNarrationGenerator(private val context: Context) {
    data class Result(val audioFile: File, val voiceName: String)

    fun generate(text: String): Result {
        require(text.isNotBlank()) { "Enter a Sinhala narration script first." }
        val ready = CountDownLatch(1)
        var initStatus = TextToSpeech.ERROR
        var engine: TextToSpeech? = null
        engine = TextToSpeech(context.applicationContext) { status ->
            initStatus = status
            ready.countDown()
        }
        try {
            check(ready.await(30, TimeUnit.SECONDS)) { "Sinhala voice engine took too long to start." }
            check(initStatus == TextToSpeech.SUCCESS) { "No text-to-speech engine is available on this phone." }

            val languageResult = engine.setLanguage(Locale("si", "LK"))
            check(languageResult != TextToSpeech.LANG_MISSING_DATA &&
                languageResult != TextToSpeech.LANG_NOT_SUPPORTED) {
                "Sinhala TTS voice is not installed. Install Sinhala voice data in Android Text-to-Speech settings."
            }

            val sinhalaVoices = engine.voices.orEmpty()
                .filter { it.locale.language.equals("si", true) }
                .sortedWith(compareByDescending<android.speech.tts.Voice> {
                    it.name.contains("male", true) ||
                        it.name.contains("sameera", true) ||
                        it.name.contains("man", true)
                }.thenByDescending { it.quality })
            val chosenVoice = sinhalaVoices.firstOrNull()
            if (chosenVoice != null) engine.voice = chosenVoice
            val voiceName = chosenVoice?.name ?: "System Sinhala default voice"

            val wav = File(context.cacheDir, "dreamx_voice_${System.currentTimeMillis()}.wav")
            val done = CountDownLatch(1)
            val synthesisError = AtomicReference<String?>(null)
            engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) { done.countDown() }
                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    synthesisError.set("The Sinhala TTS engine reported a narration error.")
                    done.countDown()
                }
                override fun onError(utteranceId: String?, errorCode: Int) {
                    synthesisError.set("The Sinhala TTS engine failed (error code $errorCode). Check installed Sinhala voice data.")
                    done.countDown()
                }
            })
            val params = android.os.Bundle()
            val result = engine.synthesizeToFile(text, params, wav, "dreamx_narration")
            check(result == TextToSpeech.SUCCESS) { "Could not start Sinhala narration synthesis." }
            check(done.await(120, TimeUnit.SECONDS)) { "Sinhala narration generation timed out after 120 seconds." }
            synthesisError.get()?.let { throw IllegalStateException(it) }
            check(wav.exists() && wav.length() > 1000L) { "Sinhala voice engine did not create an audio file." }

            val m4a = File(context.cacheDir, "dreamx_narration_${System.currentTimeMillis()}.m4a")
            encodeWavToAac(wav, m4a)
            wav.delete()
            return Result(m4a, voiceName)
        } finally {
            engine.stop()
            engine.shutdown()
        }
    }


    private fun encodeWavToAac(wav: File, output: File) {
        // Android TextToSpeech.synthesizeToFile writes a PCM WAV file. MediaExtractor
        // does not support WAV consistently across Android devices, so parse the RIFF
        // chunks directly and feed PCM frames to the AAC encoder.
        var encoder: MediaCodec? = null
        var muxer: MediaMuxer? = null
        var muxerStarted = false
        var audioTrack = -1
        val info = MediaCodec.BufferInfo()
        try {
            val bytes = wav.readBytes()
            require(bytes.size > 44 && String(bytes, 0, 4, Charsets.US_ASCII) == "RIFF" &&
                String(bytes, 8, 4, Charsets.US_ASCII) == "WAVE") {
                "Sinhala TTS did not produce a valid WAV audio file."
            }
            var offset = 12
            var sampleRate = 0
            var channels = 0
            var bitsPerSample = 0
            var audioOffset = -1
            var audioSize = 0
            var pcmFormat = 0
            while (offset + 8 <= bytes.size) {
                val id = String(bytes, offset, 4, Charsets.US_ASCII)
                val size = ((bytes[offset + 4].toInt() and 0xff) or
                    ((bytes[offset + 5].toInt() and 0xff) shl 8) or
                    ((bytes[offset + 6].toInt() and 0xff) shl 16) or
                    ((bytes[offset + 7].toInt() and 0xff) shl 24))
                val dataStart = offset + 8
                if (id == "fmt " && size >= 16 && dataStart + 16 <= bytes.size) {
                    pcmFormat = (bytes[dataStart].toInt() and 0xff) or
                        ((bytes[dataStart + 1].toInt() and 0xff) shl 8)
                    channels = (bytes[dataStart + 2].toInt() and 0xff) or
                        ((bytes[dataStart + 3].toInt() and 0xff) shl 8)
                    sampleRate = (bytes[dataStart + 4].toInt() and 0xff) or
                        ((bytes[dataStart + 5].toInt() and 0xff) shl 8) or
                        ((bytes[dataStart + 6].toInt() and 0xff) shl 16) or
                        ((bytes[dataStart + 7].toInt() and 0xff) shl 24)
                    bitsPerSample = (bytes[dataStart + 14].toInt() and 0xff) or
                        ((bytes[dataStart + 15].toInt() and 0xff) shl 8)
                } else if (id == "data") {
                    audioOffset = dataStart
                    audioSize = size.coerceAtMost(bytes.size - dataStart)
                    break
                }
                offset = dataStart + size + (size and 1)
            }
            require(pcmFormat == 1 && (bitsPerSample == 16 || bitsPerSample == 8) &&
                channels in 1..2 && sampleRate >= 8000 && audioOffset >= 0 && audioSize > 0) {
                "Unsupported Sinhala TTS WAV format (PCM ${bitsPerSample}-bit, $channels channels)."
            }

            val aacFormat = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, sampleRate, channels).apply {
                setInteger(MediaFormat.KEY_AAC_PROFILE, android.media.MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                setInteger(MediaFormat.KEY_BIT_RATE, 128000)
                setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
            }
            encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
            encoder.configure(aacFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            encoder.start()

            var inputOffset = audioOffset
            val audioEnd = audioOffset + audioSize
            var eosQueued = false
            var outputDone = false
            val bytesPerFrame = channels * (bitsPerSample / 8)
            var presentationUs = 0L
            while (!outputDone) {
                if (!eosQueued) {
                    val inputIndex = encoder.dequeueInputBuffer(10000)
                    if (inputIndex >= 0) {
                        val inputBuffer = encoder.getInputBuffer(inputIndex)!!
                        inputBuffer.clear()
                        val remaining = audioEnd - inputOffset
                        if (remaining <= 0) {
                            encoder.queueInputBuffer(
                                inputIndex, 0, 0, presentationUs,
                                MediaCodec.BUFFER_FLAG_END_OF_STREAM
                            )
                            eosQueued = true
                        } else {
                            val capacity = inputBuffer.remaining()
                            val count = minOf(capacity, remaining)
                            val alignedCount = count - (count % bytesPerFrame)
                            check(alignedCount > 0) { "AAC encoder input buffer is too small for one PCM audio frame." }
                            inputBuffer.put(bytes, inputOffset, alignedCount)
                            val frames = alignedCount / bytesPerFrame
                            val isLastChunk = inputOffset + alignedCount >= audioEnd
                            encoder.queueInputBuffer(
                                inputIndex, 0, alignedCount, presentationUs,
                                if (isLastChunk) MediaCodec.BUFFER_FLAG_END_OF_STREAM else 0
                            )
                            presentationUs += frames * 1_000_000L / sampleRate
                            inputOffset += alignedCount
                            if (isLastChunk) eosQueued = true
                        }
                    }
                }

                val outputIndex = encoder.dequeueOutputBuffer(info, 10000)
                when {
                    outputIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        check(muxer == null) { "AAC encoder changed output format more than once." }
                        muxer = MediaMuxer(output.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
                        audioTrack = muxer.addTrack(encoder.outputFormat)
                        muxer.start()
                        muxerStarted = true
                    }
                    outputIndex >= 0 -> {
                        val buffer = encoder.getOutputBuffer(outputIndex)
                        if (buffer != null && info.size > 0 && muxerStarted &&
                            info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG == 0) {
                            buffer.position(info.offset)
                            buffer.limit(info.offset + info.size)
                            muxer!!.writeSampleData(audioTrack, buffer, info)
                        }
                        outputDone = info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                        encoder.releaseOutputBuffer(outputIndex, false)
                    }
                }
            }
            check(muxerStarted && output.exists() && output.length() > 1000L) {
                "AAC encoder did not create a valid narration track."
            }
            muxer!!.stop()
            muxerStarted = false
        } catch (e: Exception) {
            output.delete()
            throw IllegalStateException("Sinhala voice audio conversion failed: ${e.message ?: e.javaClass.simpleName}", e)
        } finally {
            runCatching { encoder?.stop() }
            runCatching { encoder?.release() }
            runCatching { if (muxerStarted) muxer?.stop() }
            runCatching { muxer?.release() }
            wav.delete()
        }
    }

}
