package com.dreamxhomes.reelmaker

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.io.File
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Generates Sinhala narration with the phone's installed TTS engine and encodes it as AAC/M4A.
 * A male voice is selected when the installed engine exposes one; Android does not expose
 * reliable voice-gender metadata, so the selected voice name is returned for transparency.
 */
class SinhalaNarrationGenerator(private val context: Context) {
    data class Result(val audioFile: File, val voiceName: String)

    fun generate(text: String): Result {
        require(text.isNotBlank()) { "Enter a Sinhala narration script first." }
        val ready = CountDownLatch(1)
        var initStatus = TextToSpeech.ERROR
        var engine: TextToSpeech? = null
        engine = TextToSpeech(context.applicationContext) { status ->
            initStatus = status
            ready.countDown()
        }
        try {
            check(ready.await(30, TimeUnit.SECONDS)) { "Sinhala voice engine took too long to start." }
            check(initStatus == TextToSpeech.SUCCESS) { "No text-to-speech engine is available on this phone." }

            val languageResult = engine.setLanguage(Locale("si", "LK"))
            check(languageResult != TextToSpeech.LANG_MISSING_DATA &&
                languageResult != TextToSpeech.LANG_NOT_SUPPORTED) {
                "Sinhala TTS voice is not installed. Install Sinhala voice data in Android Text-to-Speech settings."
            }

            val sinhalaVoices = engine.voices.orEmpty()
                .filter { it.locale.language.equals("si", true) }
                .sortedWith(compareByDescending<android.speech.tts.Voice> {
                    it.name.contains("male", true) ||
                        it.name.contains("sameera", true) ||
                        it.name.contains("man", true)
                }.thenByDescending { it.quality })
            val chosenVoice = sinhalaVoices.firstOrNull()
            if (chosenVoice != null) engine.voice = chosenVoice
            val voiceName = chosenVoice?.name ?: "System Sinhala default voice"

            val wav = File(context.cacheDir, "dreamx_voice_${System.currentTimeMillis()}.wav")
            val done = CountDownLatch(1)
            engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) { done.countDown() }
                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) { done.countDown() }
                override fun onError(utteranceId: String?, errorCode: Int) { done.countDown() }
            })
            val params = android.os.Bundle()
            val result = engine.synthesizeToFile(text, params, wav, "dreamx_narration")
            check(result == TextToSpeech.SUCCESS) { "Could not start Sinhala narration synthesis." }
            check(done.await(120, TimeUnit.SECONDS)) { "Sinhala narration generation timed out." }
            check(wav.exists() && wav.length() > 1000L) { "Sinhala voice engine did not create an audio file." }

            val m4a = File(context.cacheDir, "dreamx_narration_${System.currentTimeMillis()}.m4a")
            encodeWavToAac(wav, m4a)
            wav.delete()
            return Result(m4a, voiceName)
        } finally {
            engine.stop()
            engine.shutdown()
        }
    }

    private fun encodeWavToAac(wav: File, output: File) {
        val extractor = MediaExtractor()
        var encoder: MediaCodec? = null
        var muxer: MediaMuxer? = null
        var muxerStarted = false
        var audioTrack = -1
        val info = MediaCodec.BufferInfo()
        try {
            extractor.setDataSource(wav.absolutePath)
            var sourceTrack = -1
            for (i in 0 until extractor.trackCount) {
                if ((extractor.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: "").startsWith("audio/")) {
                    sourceTrack = i
                    break
                }
            }
            check(sourceTrack >= 0) { "The phone's TTS output format is not supported." }
            val sourceFormat = extractor.getTrackFormat(sourceTrack)
            val sampleRate = sourceFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            val channels = sourceFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            val aacFormat = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, sampleRate, channels).apply {
                setInteger(MediaFormat.KEY_AAC_PROFILE, android.media.MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                setInteger(MediaFormat.KEY_BIT_RATE, 96000)
                setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
            }
            encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
            encoder.configure(aacFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            encoder.start()
            extractor.selectTrack(sourceTrack)

            var inputDone = false
            var outputDone = false
            while (!outputDone) {
                if (!inputDone) {
                    val inputIndex = encoder.dequeueInputBuffer(10000)
                    if (inputIndex >= 0) {
                        val inputBuffer = encoder.getInputBuffer(inputIndex)!!
                        inputBuffer.clear()
                        val size = extractor.readSampleData(inputBuffer, 0)
                        if (size < 0) {
                            encoder.queueInputBuffer(inputIndex, 0, 0,
                                maxOf(0L, extractor.sampleTime), MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            val pts = maxOf(0L, extractor.sampleTime)
                            encoder.queueInputBuffer(inputIndex, 0, size, pts, 0)
                            extractor.advance()
                        }
                    }
                }

                val outputIndex = encoder.dequeueOutputBuffer(info, 10000)
                when {
                    outputIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        muxer = MediaMuxer(output.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
                        audioTrack = muxer.addTrack(encoder.outputFormat)
                        muxer.start()
                        muxerStarted = true
                    }
                    outputIndex >= 0 -> {
                        val buffer = encoder.getOutputBuffer(outputIndex)
                        if (buffer != null && info.size > 0 && muxerStarted &&
                            info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG == 0) {
                            buffer.position(info.offset)
                            buffer.limit(info.offset + info.size)
                            muxer!!.writeSampleData(audioTrack, buffer, info)
                        }
                        outputDone = info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                        encoder.releaseOutputBuffer(outputIndex, false)
                    }
                }
            }
            check(muxerStarted && output.exists() && output.length() > 1000L) {
                "Could not encode Sinhala narration as AAC audio."
            }
            muxer!!.stop()
            muxerStarted = false
        } catch (e: Exception) {
            output.delete()
            throw e
        } finally {
            runCatching { extractor.release() }
            runCatching { encoder?.stop() }
            runCatching { encoder?.release() }
            runCatching { if (muxerStarted) muxer?.stop() }
            runCatching { muxer?.release() }
            wav.delete()
        }
    }
}
