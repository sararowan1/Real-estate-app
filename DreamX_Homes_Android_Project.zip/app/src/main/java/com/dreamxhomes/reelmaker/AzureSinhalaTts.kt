package com.dreamxhomes.reelmaker

import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** Azure Speech Sinhala (Sri Lanka) natural male voice client. */
class AzureSinhalaTts {
    fun synthesizeToWav(subscriptionKey: String, region: String, text: String, output: File): File {
        require(subscriptionKey.isNotBlank()) { "Add your Azure Speech subscription key in Voice Settings." }
        require(region.matches(Regex("[a-z0-9-]{3,40}"))) { "Invalid Azure Speech region." }
        require(text.isNotBlank()) { "Enter a Sinhala narration script first." }
        require(text.toByteArray(Charsets.UTF_8).size <= 9000) { "Please shorten the narration." }

        val endpoint = URL("https://$region.tts.speech.microsoft.com/cognitiveservices/v1")
        val connection = (endpoint.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 8000
            readTimeout = 30000
            doOutput = true
            setRequestProperty("Ocp-Apim-Subscription-Key", subscriptionKey.trim())
            setRequestProperty("Content-Type", "application/ssml+xml; charset=utf-8")
            setRequestProperty("X-Microsoft-OutputFormat", "riff-24khz-16bit-mono-pcm")
            setRequestProperty("User-Agent", "DreamXHomesAndroid")
        }
        try {
            val safeText = escapeXml(text)
            val ssml = """<speak version="1.0" xmlns="http://www.w3.org/2001/10/synthesis" xml:lang="si-LK"><voice name="si-LK-SameeraNeural"><prosody rate="0%" pitch="0%">$safeText</prosody></voice></speak>"""
            connection.outputStream.use { it.write(ssml.toByteArray(Charsets.UTF_8)) }
            val status = connection.responseCode
            if (status !in 200..299) {
                val detail = (connection.errorStream?.bufferedReader()?.use { it.readText() } ?: "").take(350)
                val message = when (status) {
                    401, 403 -> "Azure Speech authentication failed ($status). Check the subscription key and resource region."
                    429 -> "Azure Speech quota or rate limit reached (HTTP 429). Check your Azure Speech pricing tier and quota."
                    else -> "Azure Speech request failed ($status): $detail"
                }
                throw IllegalStateException(message)
            }
            val audio = connection.inputStream.use { it.readBytes() }
            require(audio.size > 44 && String(audio.copyOfRange(0, 4), Charsets.US_ASCII) == "RIFF") {
                "Azure Speech returned an invalid WAV audio file."
            }
            output.parentFile?.mkdirs()
            val temporary = File(output.parentFile, output.name + ".tmp")
            temporary.writeBytes(audio)
            if (output.exists()) output.delete()
            if (!temporary.renameTo(output)) {
                temporary.copyTo(output, overwrite = true)
                temporary.delete()
            }
            return output
        } finally {
            connection.disconnect()
        }
    }

    private fun escapeXml(value: String): String = value
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace("\"", "&quot;")
        .replace("'", "&apos;")
}
